/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';
import { scraperEngine } from './src/server/scraperEngine.js';
import { ExtractionParams } from './src/types/scraper.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // API Routes

  // 1. Get Status
  app.get('/api/search/status', (req: Request, res: Response) => {
    res.json(scraperEngine.getLightState());
  });

  // 1a. Ricerca nel testo integrale delle pronunce acquisite
  app.get('/api/documents/search', (req: Request, res: Response) => {
    const q = String(req.query.q || '').trim();
    res.json({ ids: q ? scraperEngine.searchDocumentText(q) : [] });
  });

  // 1b. Singola pronuncia con testo integrale
  app.get('/api/documents/:id', (req: Request, res: Response) => {
    const doc = scraperEngine.getDocument(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Pronuncia non trovata' });
    res.json(doc);
  });

  // 1c. Documento originale (PDF o HTML) così come scaricato dal portale
  app.get('/api/documents/:id/original', (req: Request, res: Response) => {
    const orig = scraperEngine.getOriginal(req.params.id);
    if (!orig) return res.status(404).json({ error: 'Documento originale non disponibile' });
    const disposition = req.query.download ? 'attachment' : 'inline';
    res.setHeader('Content-Type', orig.mime);
    res.setHeader('Content-Disposition', `${disposition}; filename="${req.params.id}.${orig.ext}"`);
    // Gli HTML del portale vengono mostrati in un iframe isolato: niente script
    if (orig.ext === 'html') res.setHeader('Content-Security-Policy', "script-src 'none'");
    res.send(orig.buffer);
  });

  // 2. Start Search
  app.post('/api/search/start', async (req: Request, res: Response) => {
    const params: ExtractionParams = {
      paroleChiave: req.body.paroleChiave || 'gara',
      fraseEsatta: req.body.fraseEsatta || '',
      tipoProvvedimento: req.body.tipoProvvedimento || '',
      sede: req.body.sede || '',
      modalitaRicerca: req.body.modalitaRicerca || 'provv',
      risultatiPerPagina: Number(req.body.risultatiPerPagina) || 60,
    };
    const result = await scraperEngine.start(params);
    res.json(result);
  });

  // 3. Pause
  app.post('/api/search/pause', (req: Request, res: Response) => {
    res.json(scraperEngine.pause());
  });

  // 4. Resume
  app.post('/api/search/resume', (req: Request, res: Response) => {
    res.json(scraperEngine.resume());
  });

  // 5. Stop
  app.post('/api/search/stop', (req: Request, res: Response) => {
    res.json(scraperEngine.stop());
  });

  // 6. SSE Real-time Events
  app.get('/api/search/events', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    // Send initial state
    res.write(`data: ${JSON.stringify(scraperEngine.getLightState())}\n\n`);

    const unsubscribe = scraperEngine.subscribe((state) => {
      res.write(`data: ${JSON.stringify(state)}\n\n`);
    });

    req.on('close', () => {
      unsubscribe();
    });
  });

  // 7. Export ZIP
  app.get('/api/export/zip', async (req: Request, res: Response) => {
    try {
      const state = scraperEngine.getState();
      const zipBuffer = await scraperEngine.generateZipArchive();
      const filename = `${state.cartellaOutput || 'Sentenze_GA'}.zip`;

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(zipBuffer);
    } catch (err: any) {
      res.status(500).json({ error: 'Errore durante la creazione dello ZIP: ' + err.message });
    }
  });

  // 8. Export CSV
  app.get('/api/export/csv', (req: Request, res: Response) => {
    const state = scraperEngine.getState();
    const csvContent = scraperEngine.generateCsvIndex();
    const filename = `indice_pronunce_${state.cartellaOutput}.csv`;

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(csvContent);
  });

  // 9. Export Report
  app.get('/api/export/report', (req: Request, res: Response) => {
    const format = req.query.format === 'json' ? 'json' : 'md';
    if (format === 'json') {
      const report = scraperEngine.generateAuditReport();
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="report_estrazione.json"');
      res.send(JSON.stringify(report, null, 2));
    } else {
      const reportMd = scraperEngine.generateMarkdownReport();
      res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="report_estrazione.md"');
      res.send(reportMd);
    }
  });

  // 10. Export Windows Standalone Script Package
  app.get('/api/export/windows-package', async (req: Request, res: Response) => {
    try {
      const { batScript, pythonScript, readme } = scraperEngine.generateWindowsStandalonePackage();
      const zip = new JSZip();
      const folder = zip.folder('Estrattore_GA_Windows');
      if (folder) {
        folder.file('run_estrazione.bat', batScript);
        folder.file('estrattore_ga.py', pythonScript);
        folder.file('ISTRUZIONI_WINDOWS.md', readme);
      }
      const buffer = await zip.generateAsync({ type: 'nodebuffer' });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="Estrattore_GA_Windows_Standalone.zip"');
      res.send(buffer);
    } catch (err: any) {
      res.status(500).json({ error: 'Errore creazione pacchetto Windows: ' + err.message });
    }
  });

  // 11. Scheduler endpoints
  app.get('/api/scheduler', (req: Request, res: Response) => {
    res.json(scraperEngine.getScheduleConfig());
  });

  app.post('/api/scheduler', (req: Request, res: Response) => {
    const updated = scraperEngine.updateScheduleConfig(req.body);
    res.json(updated);
  });

  // 12. Diagnostics
  app.post('/api/diagnostics', async (req: Request, res: Response) => {
    const results: any = {
      timestamp: new Date().toISOString(),
      portalUrl: 'https://www.giustizia-amministrativa.it/web/guest/dcsnprr',
      mdpRepositoryUrl: 'https://mdp.giustizia-amministrativa.it/visualizza/',
      portalReachability: false,
      portalLatencyMs: 0,
      sessionCookieAcquired: false,
      formActionFound: false,
      pAuthTokenFound: false,
      portletInstance: '',
      errors: [] as string[],
    };

    const start = Date.now();
    try {
      const response = await fetch('https://www.giustizia-amministrativa.it/web/guest/dcsnprr', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        },
      });
      results.portalLatencyMs = Date.now() - start;
      results.portalReachability = response.ok;
      results.portalHttpStatus = response.status;

      const rawCookies = (response.headers as any).getSetCookie
        ? (response.headers as any).getSetCookie()
        : [response.headers.get('set-cookie')];
      results.sessionCookieAcquired = Array.isArray(rawCookies) && rawCookies.length > 0;

      const html = await response.text();
      const formMatch = html.match(/<form[^>]+class="form-provvedimenti"[^>]+action="([^"]+)"/);
      if (formMatch) {
        results.formActionFound = true;
        results.formActionUrl = formMatch[1];
        results.pAuthTokenFound = formMatch[1].includes('p_auth=');
        const instMatch = formMatch[1].match(/INSTANCE_([a-zA-Z0-9]+)/);
        if (instMatch) results.portletInstance = instMatch[1];
      }
    } catch (err: any) {
      results.errors.push(err.message);
    }

    res.json(results);
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[GA-Scraper] Server online listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
