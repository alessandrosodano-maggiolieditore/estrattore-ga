# Estrattore Massivo Pronunce Giustizia Amministrativa

Applicazione web full-stack per l'estrazione massiva, sistematica e verificata delle pronunce pubblicate sul portale ufficiale della Giustizia Amministrativa (`giustizia-amministrativa.it/de/dcsnprr`), conforme ai criteri di ricerca avanzata, paginazione integrale, acquisizione documentale completa (TXT, HTML, PDF), reportistica e automazione programmata.

## User Review & Critical Decisions

> [!IMPORTANT]
> **Decisioni confermate in fase di chiarimento**:
> - **Modalità di esecuzione**: Applicazione web nativa attiva nel browser con motore di estrazione backend Node.js ad alte prestazioni, con esportazione completa in archivio ZIP `Sentenze_GA_AAAA-MM-GG`.
> - **Formati di conservazione**: Entrambi i formati originali HTML e PDF oltre al testo integrale in formato TXT UTF-8 strutturato (epigrafe, premessa, dispositivo P.Q.M., sottoscrizioni).
> - **Automazione**: Supporto combinato per avvio manuale istantaneo e pianificatore giornaliero automatico (Europe/Rome).

## 1. Overview & Core Concept

- **Cosa fa**: Interroga il motore "Decisioni e Pareri" (`/web/guest/dcsnprr`) della Giustizia Amministrativa, imposta automaticamente i parametri richiesti ("gara", data odierna GG/MM/AAAA con fuso orario Europe/Rome, risultati per pagina al massimo consentito = 60, modalità "Provvedimento"), attraversa tutte le pagine dei risultati senza interruzioni e scarica per ogni pronuncia i metadati, il testo integrale e i documenti originali.
- **Destinatari**: Professionisti legali, studi legali amministrativisti, analisti di gare pubbliche e data scientist che necessitano di raccogliere corpus giurisprudenziali completi e verificabili senza scrivere codice.
- **Valore chiave**: Risoluzione del problema dei portali giudiziari complessi (gestione delle sessioni Liferay, token `p_auth`, paginazione dinamica `cur`/`delta`, formati XML/HTML nativi di `mdp.giustizia-amministrativa.it`), garantendo zero omissioni, deduplicazione rigorosa e report di audit certificato.

## 2. User Experience & Visual Design

- **Flussi Utente**:
  1. *Configurazione & Avvio*: La schermata iniziale presenta i parametri precompilati (Data odierna GG/MM/AAAA calcolata su Europe/Rome, parola chiave "gara", modalità Provvedimento, max 60 risultati/pagina). L'utente può modificare la data o i termini con un clic e premere "Avvia estrazione".
  2. *Monitoraggio in Tempo Reale*: L'interfaccia si attiva con un pannello di avanzamento a metriche vive:
     - Risultati totali dichiarati dal portale
     - Pagine attraversate / Pagine totali
     - Documenti individuati vs Documenti acquisiti con successo
     - Documenti con errori o retry
     - Eventuali duplicati scartati
     - Barra di progresso percentuale con indicatore di velocità e stima temporale
  3. *Controllo Operativo*: Pulsanti dedicati per "Metti in pausa", "Riprendi" e "Interrompi". In caso di interruzione, lo stato viene preservato per consentire la ripresa senza riscaricare i documenti già acquisiti.
  4. *Esplorazione & Download*: Tabella interattiva dei provvedimenti acquisiti con ricerca/filtri rapidi (per TAR, Consiglio di Stato, numero, data). Anteprima istantanea del testo integrale estratto (TXT), della vista HTML originale e del file PDF.
  5. *Esportazione Massiva*: Pulsante "Scarica Archivio Completo (ZIP)" che produce la cartella conforme `Sentenze_GA_AAAA-MM-GG.zip` contenente `documenti_originali/`, `testi_integrali/`, `indice_pronunce.csv`, `report_estrazione.json` e `report_estrazione.md`.
  6. *Pianificatore Giornaliero*: Sezione per attivare l'estrazione automatica quotidiana a un'ora prestabilita (es. 08:30 Europe/Rome) con log delle esecuzioni pregresse.

- **Identità Visiva & Tema**:
  - *Stile*: Istituzionale, sobrio, di livello professionale giuridico/enterprise, privo di elementi futili o slop grafico.
  - *Palette*: Sfondo neutro pulito (`#0F172A` / `#F8FAFC`), superfici strutturate (`#FFFFFF` in light mode, `#1E293B` in dark mode), accenti blu istituzionale giustizia (`#1E40AF` / `#2563EB`) e verde successo (`#16A34A`).
  - *Tipografia*: `Plus Jakarta Sans` per i titoli e la navigazione, `Public Sans` per il testo analitico, e `JetBrains Mono` / `tabular-nums` per numeri di registro generale, ECLI, date e contatori di avanzamento.
  - *Zero-Pill Discipline*: Nessuna pillola decorativa; metadati visualizzati con separatori tipografici chiari (`·`, `/`).

## 3. Scelte Architetturali & Trade-Offs

- **Scelta del Motore di Acquisizione (Backend Node.js nativo vs Browser Headless Pesante)**:
  - *Approccio*: Utilizzo di un client HTTP backend con gestione delle sessioni Liferay, cookie jar e negoziazione dei token `p_auth`.
  - *Motivazione*: I test reali eseguiti sul portale (`https://www.giustizia-amministrativa.it/web/guest/dcsnprr`) hanno confermato che il portale risponde in modo affidabile, veloce e senza dipendenze pesanti a richieste standard ben strutturate con cookie Liferay e token `p_auth`. Questo garantisce un'estrazione da 5 a 10 volte più veloce rispetto a un browser Chromium headless, riducendo drasticamente il consumo di memoria e azzerando i crash da timeout.
  - *Fallback/Diagnostica integrata*: Inclusione di un modulo diagnostico con verifica dello stato dei selettori e degli endpoint.
- **Generazione Documenti & Formati**:
  - *HTML Originale*: Salvataggio del documento sorgente XML/HTML originale restituito da `mdp.giustizia-amministrativa.it`.
  - *TXT Integrale*: Parsing strutturato dei tag XML (`<epigrafe>`, `<premessa>`, `<dispositivo>`, `<sottoscrizioni>`) per produrre un testo UTF-8 pulito con paragrafi preservati, ideale per ingestione in LLM o database legali.
  - *PDF Originale / Renderizzato*: Generazione del PDF print-ready tramite rendering server-side del documento ufficiale.
  - *Indice CSV & Report*: Creazione di `indice_pronunce.csv` con intestazioni standard e `report_estrazione.md` / `report_estrazione.json` con metadati e metriche di audit.

## 4. Architettura Tecnica & Flusso Dati

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Interfaccia Utente (React)                      │
│  ┌──────────────────────┬──────────────────────┬────────────────────┐  │
│  │ Maschera di Ricerca  │  Pannello Avanzamento│ Visualizzatore Doc │  │
│  │ (Data, Gara, Filtri) │  (Pagine, Totale, %) │ (TXT, HTML, PDF)   │  │
│  └──────────┬───────────┴──────────┬───────────┴─────────┬──────────┘  │
└─────────────┼──────────────────────┼─────────────────────┼─────────────┘
              │ Avvio / Parametri    │ Eventi SSE (Progresso)│ Download / Preview
              ▼                      ▼                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│                      Server Express (Backend API)                      │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ /api/search/start   /api/search/status   /api/search/pause       │  │
│  │ /api/documents/:id  /api/export/zip      /api/schedule           │  │
│  └─────────────────────────────────┬────────────────────────────────┘  │
│                                    ▼                                   │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │                GA Scraper Engine (Liferay Client)                │  │
│  │  1. Inizializzazione Sessione (JSESSIONID + p_auth)              │  │
│  │  2. Post Ricerca Avanzata (searchAllWords=gara, searchPhrase=...) │  │
│  │  3. Rilevamento Totale & Calcolo Pagine (delta=60)               │  │
│  │  4. Paginazione Sistematica (cur=1..N)                           │  │
│  │  5. Acquisizione da mdp.giustizia-amministrativa.it              │  │
│  │  6. Generazione TXT, HTML, PDF, Indice CSV & Audit Report        │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │ Richieste HTTP / HTTPS
                                     ▼
     ┌───────────────────────────────────────────────────────────────┐
     │ Portale Ufficiale della Giustizia Amministrativa (dcsnprr)     │
     │ e Repositorio Documentale (mdp.giustizia-amministrativa.it)   │
     └───────────────────────────────────────────────────────────────┘
```

- **Sequenza Operativa**:
  1. Il backend invia una GET a `/web/guest/dcsnprr` per raccogliere `JSESSIONID` e il token `p_auth`.
  2. Esegue la POST con `searchAllWords="gara"`, `searchPhrase=DataCorrente`, `searchMode="provv"`, `pageSize="60"`.
  3. Estrae il numero totale dei risultati con regex verificata: `Risultati da 1 a X di TOTAL totali`.
  4. Per ciascuna pagina da `cur=1` a `Math.ceil(TOTAL / 60)`:
     - Estrae tutti gli articoli `article.ricerca--item` con sede, sezione, data, tipologia, numero provv, numero RG, ECLI, URL.
     - Scarica il file da `mdp.giustizia-amministrativa.it/visualizza/?...`.
     - Estrae il testo completo e lo converte in TXT UTF-8 strutturato.
     - Genera l'HTML e il PDF.
     - Emette evento SSE di avanzamento al client.
  5. Al termine, crea l'indice `indice_pronunce.csv`, il file `report_estrazione.json`, `report_estrazione.md` e pacchettizza l'archivio `Sentenze_GA_AAAA-MM-GG.zip`.
