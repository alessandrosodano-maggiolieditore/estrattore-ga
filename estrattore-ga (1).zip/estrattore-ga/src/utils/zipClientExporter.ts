/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExtractionState } from '../types/scraper.js';

export interface ExportProgressCallback {
  (message: string, current?: number, total?: number): void;
}

/**
 * Scarica l'archivio ZIP generato dal server, che contiene i documenti originali
 * (PDF/HTML) e i testi integrali, non presenti nello stato inviato al browser.
 */
export async function downloadSentenzeZipClient(
  state: ExtractionState,
  onProgress?: ExportProgressCallback
): Promise<void> {
  if (state.pronunceAcquisite === 0) {
    throw new Error('Nessuna sentenza acquisita disponibile per la generazione dell\'archivio ZIP.');
  }

  onProgress?.('Generazione archivio ZIP sul server...');
  const res = await fetch('/api/export/zip');
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(body?.error || `HTTP ${res.status}`);
  }

  onProgress?.('Download archivio in corso...');
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${state.cartellaOutput || 'Sentenze_GA'}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
