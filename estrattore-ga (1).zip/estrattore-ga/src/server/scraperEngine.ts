/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';
import { jsPDF } from 'jspdf';
import { extractText, getDocumentProxy } from 'unpdf';
import {
  AuditReport,
  ExtractionParams,
  ExtractionState,
  GAPronuncia,
  LogEntry,
  ScheduleConfig,
} from '../types/scraper.js';

type ParsedDocument = {
  fullText: string;
  sections: GAPronuncia['testoSezioni'];
  dataPubblicazione?: string;
};

export function getRomeDateString(): string {
  try {
    const formatter = new Intl.DateTimeFormat('it-IT', {
      timeZone: 'Europe/Rome',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
    return formatter.format(new Date()); // e.g. "20/10/2026"
  } catch (err) {
    const d = new Date();
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  }
}

export function getRomeDateFolderSlug(dateStr: string): string {
  // Convert DD/MM/YYYY to YYYY-MM-DD
  const parts = dateStr.split('/');
  if (parts.length === 3) {
    return `Sentenze_GA_${parts[2]}-${parts[1]}-${parts[0]}`;
  }
  const clean = dateStr.replace(/[^a-zA-Z0-9]/g, '_');
  return `Sentenze_GA_${clean}`;
}

// Oltre questa soglia l'estrazione non parte: tutto è tenuto in memoria e una ricerca senza data
// (es. solo "gara") restituisce centinaia di migliaia di provvedimenti
const MAX_RISULTATI = 5000;

export class ScraperEngine {
  private state: ExtractionState;
  private isPaused: boolean = false;
  private isStopped: boolean = false;
  private listeners: Array<(state: ExtractionState) => void> = [];
  private sessionCookies: string = '';
  private actionUrl: string = '';
  private portletInstance: string = 'XKc17mrB8J10';
  private portletPrefix: string = '_decisioni_pareri_web_DecisioniPareriWebPortlet_INSTANCE_XKc17mrB8J10_';
  private scheduleConfig: ScheduleConfig = {
    attivo: false,
    ora: '08:00',
    paroleChiave: 'gara',
    usaDataCorrente: true,
    ultimaEsecuzione: null,
    prossimaEsecuzione: null,
    statoUltimaEsecuzione: null,
  };
  private scheduleTimer: NodeJS.Timeout | null = null;
  // Documenti originali scaricati (binari), tenuti fuori dallo stato inviato al client
  private originals: Map<string, { buffer: Buffer; mime: string; ext: 'pdf' | 'html' }> = new Map();

  constructor() {
    this.state = this.getInitialState();
    this.initScheduler();
  }

  private getInitialState(): ExtractionState {
    const defaultDate = getRomeDateString();
    return {
      jobId: '',
      status: 'idle',
      params: {
        paroleChiave: 'gara',
        fraseEsatta: defaultDate,
        tipoProvvedimento: '',
        sede: '',
        modalitaRicerca: 'provv',
        risultatiPerPagina: 60,
      },
      dataAvvio: null,
      dataFine: null,
      risultatiDichiaratiPortale: 0,
      risultatiIndividuati: 0,
      pronunceAcquisite: 0,
      acquisizioniFallite: 0,
      duplicatiScartati: 0,
      paginaCorrente: 0,
      totalePagine: 0,
      percentuale: 0,
      velocitaDocSec: 0,
      pronunce: [],
      erroriLinks: [],
      logs: [],
      cartellaOutput: getRomeDateFolderSlug(defaultDate),
    };
  }

  public subscribe(listener: (state: ExtractionState) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    for (const listener of this.listeners) {
      try {
        listener(this.getLightState());
      } catch (e) {
        console.error('Error notifying listener:', e);
      }
    }
  }

  private addLog(level: LogEntry['level'], message: string) {
    const log: LogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toLocaleTimeString('it-IT', { timeZone: 'Europe/Rome' }),
      level,
      message,
    };
    this.state.logs = [log, ...this.state.logs.slice(0, 499)]; // Keep latest 500 logs
    this.notify();
  }

  public getState(): ExtractionState {
    return { ...this.state };
  }

  // Stato senza testi integrali, inviato al client via SSE/status per non trasferire megabyte a ogni evento
  public getLightState(): ExtractionState {
    return {
      ...this.state,
      pronunce: this.state.pronunce.map((p) => ({
        ...p,
        testoIntegrale: '',
        testoSezioni: {},
        documentoOriginaleHtml: '',
      })),
    };
  }

  public getDocument(id: string): GAPronuncia | null {
    const p = this.state.pronunce.find((x) => x.id === id);
    if (!p) return null;
    const orig = this.originals.get(id);
    return {
      ...p,
      documentoOriginaleHtml: orig && orig.ext === 'html' ? orig.buffer.toString('utf8') : '',
    };
  }

  public searchDocumentText(query: string): string[] {
    const q = query.toLowerCase();
    return this.state.pronunce.filter((p) => p.testoIntegrale.toLowerCase().includes(q)).map((p) => p.id);
  }

  public getOriginal(id: string): { buffer: Buffer; mime: string; ext: 'pdf' | 'html' } | null {
    return this.originals.get(id) || null;
  }

  public getScheduleConfig(): ScheduleConfig {
    return { ...this.scheduleConfig };
  }

  public updateScheduleConfig(config: Partial<ScheduleConfig>): ScheduleConfig {
    this.scheduleConfig = { ...this.scheduleConfig, ...config };
    this.computeNextExecution();
    return { ...this.scheduleConfig };
  }

  private computeNextExecution() {
    if (!this.scheduleConfig.attivo) {
      this.scheduleConfig.prossimaEsecuzione = null;
      return;
    }
    const [targetHour, targetMin] = this.scheduleConfig.ora.split(':').map(Number);
    const now = new Date();
    const next = new Date(now);
    next.setHours(targetHour, targetMin, 0, 0);
    if (next <= now) {
      next.setDate(next.getDate() + 1);
    }
    this.scheduleConfig.prossimaEsecuzione = next.toISOString();
  }

  private initScheduler() {
    // Check every 30 seconds
    this.scheduleTimer = setInterval(() => {
      if (!this.scheduleConfig.attivo || this.state.status === 'running') return;
      const now = new Date();
      // Rome hour & minute
      const romeTimeStr = new Intl.DateTimeFormat('it-IT', {
        timeZone: 'Europe/Rome',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      }).format(now);

      if (romeTimeStr === this.scheduleConfig.ora) {
        const todayStr = getRomeDateString();
        // Check if not already run today at this minute
        if (this.scheduleConfig.ultimaEsecuzione?.startsWith(todayStr)) return;

        this.addLog('info', `[SCHEDULER] Avvio pianificato automatico delle ore ${this.scheduleConfig.ora}`);
        this.scheduleConfig.ultimaEsecuzione = `${todayStr} ${romeTimeStr}`;
        this.start({
          paroleChiave: this.scheduleConfig.paroleChiave || 'gara',
          fraseEsatta: this.scheduleConfig.usaDataCorrente ? todayStr : this.state.params.fraseEsatta,
          tipoProvvedimento: '',
          sede: '',
          modalitaRicerca: 'provv',
          risultatiPerPagina: 60,
        }).catch((err) => {
          this.scheduleConfig.statoUltimaEsecuzione = `Errore: ${err.message}`;
          this.addLog('error', `[SCHEDULER] Errore esecuzione pianificata: ${err.message}`);
        });
      }
    }, 30000);
  }

  public async start(params: ExtractionParams): Promise<{ success: boolean; message: string }> {
    if (this.state.status === 'running') {
      return { success: false, message: 'Un lavoro di estrazione è già in corso.' };
    }

    this.isPaused = false;
    this.isStopped = false;

    const folderSlug = getRomeDateFolderSlug(params.fraseEsatta || getRomeDateString());
    this.state = {
      ...this.getInitialState(),
      jobId: 'job_' + Date.now(),
      status: 'running',
      params: { ...params },
      dataAvvio: new Date().toISOString(),
      cartellaOutput: folderSlug,
    };
    this.originals.clear();

    this.addLog('info', `Avvio estrazione massiva. Parola chiave: "${params.paroleChiave}", Data: "${params.fraseEsatta}"`);
    this.notify();

    // Run asynchronously
    this.runExtractionProcess().catch((err) => {
      this.state.status = 'failed';
      this.state.dataFine = new Date().toISOString();
      this.addLog('error', `Estrazione terminata con errore critico: ${err.message}`);
      this.notify();
    });

    return { success: true, message: 'Estrazione avviata con successo.' };
  }

  public pause(): { success: boolean; message: string } {
    if (this.state.status !== 'running') {
      return { success: false, message: 'Nessuna estrazione in esecuzione da mettere in pausa.' };
    }
    this.isPaused = true;
    this.state.status = 'paused';
    this.addLog('warn', 'Estrazione messa in pausa dall\'utente.');
    this.notify();
    return { success: true, message: 'Estrazione messa in pausa.' };
  }

  public resume(): { success: boolean; message: string } {
    if (this.state.status !== 'paused') {
      return { success: false, message: 'L\'estrazione non è attualmente in pausa.' };
    }
    this.isPaused = false;
    this.state.status = 'running';
    this.addLog('info', 'Estrazione ripresa.');
    this.notify();
    return { success: true, message: 'Estrazione ripresa.' };
  }

  public stop(): { success: boolean; message: string } {
    if (this.state.status !== 'running' && this.state.status !== 'paused') {
      return { success: false, message: 'Nessuna operazione in corso da interrompere.' };
    }
    this.isStopped = true;
    this.isPaused = false;
    this.state.status = 'stopped';
    this.state.dataFine = new Date().toISOString();
    this.addLog('warn', 'Estrazione interrotta manualmente dall\'utente.');
    this.notify();
    return { success: true, message: 'Estrazione interrotta.' };
  }

  private async sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  private async waitIfPaused(): Promise<void> {
    while (this.isPaused && !this.isStopped) {
      await this.sleep(500);
    }
  }

  private async runExtractionProcess() {
    const startTime = Date.now();
    try {
      // Step 1: Initialize session on portal
      this.addLog('info', 'Inizializzazione sessione con il portale Giustizia Amministrativa...');
      await this.initPortalSession();

      // Step 2: Submit search
      this.addLog('info', `Invio richiesta di ricerca avanzata ("${this.state.params.paroleChiave}", frase: "${this.state.params.fraseEsatta}")...`);
      const searchResultHtml = await this.executeSearchRequest(this.state.params);

      // Step 3: Parse total declared and pagination
      const { totalResults, pageSize, totalPages } = this.parseTotalCount(searchResultHtml);
      this.state.risultatiDichiaratiPortale = totalResults;
      this.state.totalePagine = totalPages;
      this.state.paginaCorrente = 1;

      this.addLog(
        'info',
        `Risultati dichiarati dal portale: ${totalResults} su ${totalPages} pagin${totalPages === 1 ? 'a' : 'e'} (${pageSize} per pagina)`
      );
      this.notify();

      if (totalResults > MAX_RISULTATI) {
        this.state.status = 'failed';
        this.state.dataFine = new Date().toISOString();
        this.addLog(
          'error',
          `Il portale dichiara ${totalResults} risultati, oltre il limite di ${MAX_RISULTATI}. Restringi la ricerca (es. data nel campo "frase esatta", sede o tipo di provvedimento).`
        );
        this.notify();
        return;
      }

      if (totalResults === 0) {
        this.state.status = 'completed';
        this.state.dataFine = new Date().toISOString();
        this.state.percentuale = 100;
        this.addLog('warn', 'Nessuna pronuncia restituita per i criteri di ricerca specificati.');
        this.notify();
        return;
      }

      // Step 4: Process pages
      let currentHtml = searchResultHtml;
      const seenIds = new Set<string>();

      for (let page = 1; page <= totalPages; page++) {
        if (this.isStopped) break;
        await this.waitIfPaused();
        if (this.isStopped) break;

        this.state.paginaCorrente = page;
        this.addLog('info', `Elaborazione pagina ${page} di ${totalPages}...`);
        this.notify();

        if (page > 1) {
          // Fetch next page via pagination URL
          currentHtml = await this.fetchPaginationPage(page, this.state.params);
        }

        // Extract articles from page HTML
        const items = this.extractArticlesFromHtml(currentHtml);
        this.addLog('info', `Pagina ${page}: individuati ${items.length} provvedimenti.`);

        for (const item of items) {
          if (this.isStopped) break;
          await this.waitIfPaused();
          if (this.isStopped) break;

          this.state.risultatiIndividuati++;

          // Deduplication check
          if (seenIds.has(item.id)) {
            this.state.duplicatiScartati++;
            this.addLog('warn', `Duplicato rilevato e scartato: Provv. ${item.numeroProvvedimento} (${item.sede})`);
            this.notify();
            continue;
          }
          seenIds.add(item.id);

          // Download full document
          await this.processDocumentItem(item);

          // Update speed & progress
          const elapsedSec = (Date.now() - startTime) / 1000;
          if (elapsedSec > 0) {
            this.state.velocitaDocSec = Number((this.state.pronunceAcquisite / elapsedSec).toFixed(2));
          }

          if (this.state.risultatiDichiaratiPortale > 0) {
            this.state.percentuale = Math.min(
              100,
              Math.round((this.state.pronunceAcquisite / this.state.risultatiDichiaratiPortale) * 100)
            );
          }
          this.notify();

          // Polite pacing between documents (150ms)
          await this.sleep(150);
        }
      }

      // Verification and completion
      this.state.dataFine = new Date().toISOString();
      if (this.isStopped) {
        this.state.status = 'stopped';
        this.addLog('warn', `Acquisizione interrotta. Acquisite ${this.state.pronunceAcquisite} pronunce.`);
      } else {
        this.state.status = 'completed';
        this.state.percentuale = 100;
        this.addLog(
          'success',
          `Acquisizione completata con successo! Pronunce acquisite: ${this.state.pronunceAcquisite}/${this.state.risultatiDichiaratiPortale}. Fallite: ${this.state.acquisizioniFallite}. Duplicati: ${this.state.duplicatiScartati}.`
        );
      }
      this.notify();
    } catch (err: any) {
      this.state.status = 'failed';
      this.state.dataFine = new Date().toISOString();
      this.addLog('error', `Errore durante il processo di estrazione: ${err.message}`);
      this.notify();
    }
  }

  private async initPortalSession(): Promise<void> {
    const res = await fetch('https://www.giustizia-amministrativa.it/web/guest/dcsnprr', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7',
      },
    });

    const html = await res.text();
    const rawCookies = (res.headers as any).getSetCookie ? (res.headers as any).getSetCookie() : [res.headers.get('set-cookie')];
    this.sessionCookies = (rawCookies || [])
      .filter(Boolean)
      .map((c: string) => c.split(';')[0])
      .join('; ');

    const formMatch = html.match(/<form[^>]+class="form-provvedimenti"[^>]+action="([^"]+)"/);
    if (!formMatch) {
      throw new Error('Impossibile individuare il form di ricerca nel portale Giustizia Amministrativa.');
    }
    this.actionUrl = formMatch[1].replace(/&amp;/g, '&');

    const instMatch = this.actionUrl.match(/INSTANCE_([a-zA-Z0-9]+)/);
    if (instMatch) {
      this.portletInstance = instMatch[1];
      this.portletPrefix = `_decisioni_pareri_web_DecisioniPareriWebPortlet_INSTANCE_${this.portletInstance}_`;
    }
  }

  private async executeSearchRequest(params: ExtractionParams): Promise<string> {
    const pfx = this.portletPrefix;
    const body = new URLSearchParams();
    body.append(`${pfx}formDate`, String(Date.now()));
    body.append(`${pfx}isAdvancedSearch`, 'true');
    body.append(`${pfx}searchAllWords`, params.paroleChiave.trim());
    body.append(`${pfx}searchAnyWords`, '');
    body.append(`${pfx}searchNotWords`, '');
    body.append(`${pfx}searchPhrase`, params.fraseEsatta.trim());
    body.append(`${pfx}asSearchMode`, params.modalitaRicerca || 'provv');
    body.append(`${pfx}searchModeRadio`, params.modalitaRicerca || 'provv');
    body.append(`${pfx}pageSize`, String(params.risultatiPerPagina || 60));
    body.append(`${pfx}TipoProvvedimentoItem`, params.tipoProvvedimento || '');
    body.append(`${pfx}sedeProvvedimenti`, params.sede || '');
    body.append(`${pfx}DataYearItem`, '');
    body.append(`${pfx}numeroProvvedimenti`, '');
    body.append(`${pfx}findBtn`, 'true');

    const res = await fetch(this.actionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': this.sessionCookies,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Origin': 'https://www.giustizia-amministrativa.it',
        'Referer': 'https://www.giustizia-amministrativa.it/web/guest/dcsnprr',
      },
      body: body.toString(),
    });

    if (!res.ok) {
      throw new Error(`Errore HTTP durante la ricerca: ${res.status} ${res.statusText}`);
    }

    // Refresh cookies if set
    const postCookies = (res.headers as any).getSetCookie ? (res.headers as any).getSetCookie() : [res.headers.get('set-cookie')];
    if (postCookies && postCookies.length) {
      const newCookies = postCookies.filter(Boolean).map((c: string) => c.split(';')[0]).join('; ');
      this.sessionCookies += '; ' + newCookies;
    }

    return await res.text();
  }

  private async fetchPaginationPage(pageNum: number, params: ExtractionParams): Promise<string> {
    const pfx = this.portletPrefix;
    const url = new URL(this.actionUrl);
    url.searchParams.set(`${pfx}searchAllWords`, params.paroleChiave.trim());
    url.searchParams.set(`${pfx}searchPhrase`, params.fraseEsatta.trim());
    url.searchParams.set(`${pfx}pageSize`, String(params.risultatiPerPagina || 60));
    url.searchParams.set(`${pfx}delta`, String(params.risultatiPerPagina || 60));
    url.searchParams.set(`${pfx}cur`, String(pageNum));
    url.searchParams.set(`${pfx}changePage`, 'true');
    url.searchParams.set(`${pfx}asSearchMode`, params.modalitaRicerca || 'provv');
    url.searchParams.set(`${pfx}TipoProvvedimentoItem`, params.tipoProvvedimento || '');
    url.searchParams.set(`${pfx}sedeProvvedimenti`, params.sede || '');

    const res = await fetch(url.toString(), {
      headers: {
        'Cookie': this.sessionCookies,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Referer': 'https://www.giustizia-amministrativa.it/web/guest/dcsnprr',
      },
    });

    if (!res.ok) {
      throw new Error(`Errore caricamento pagina ${pageNum}: HTTP ${res.status}`);
    }

    return await res.text();
  }

  private parseTotalCount(html: string): { totalResults: number; pageSize: number; totalPages: number } {
    // Portale renders: "Risultati da X a Y di TOTAL totali"
    const match = html.match(/Risultati\s+da\s+(\d+)\s+a\s+(\d+)\s+di\s+(\d+)\s+totali/i);
    let total = 0;
    let pageSize = this.state.params.risultatiPerPagina || 60;

    if (match) {
      total = parseInt(match[3], 10);
    } else {
      // Check for zero results message
      if (html.includes('Nessun risultato') || html.includes('non ha prodotto risultati')) {
        return { totalResults: 0, pageSize, totalPages: 0 };
      }
      // Fallback: count items directly in page
      const items = (html.match(/<article\s+class="ricerca--item"/gi) || []).length;
      total = items;
    }

    const totalPages = total > 0 ? Math.ceil(total / pageSize) : 0;
    return { totalResults: total, pageSize, totalPages };
  }

  private extractArticlesFromHtml(html: string): GAPronuncia[] {
    const list: GAPronuncia[] = [];
    // Match each <article class="ricerca--item">...</article>
    const articleRegex = /<article\s+class="ricerca--item">([\s\S]*?)<\/article>/gi;
    let match;

    while ((match = articleRegex.exec(html)) !== null) {
      const art = match[1];

      // Exclude the pagination footer article (which also has class ricerca--item)
      if (art.includes('col-pagination') || art.includes('Risultati da')) {
        continue;
      }

      // 1. Link to original document
      // <a data-sede="tar_rm" data-nrg="202607293" data-idprovv="..." href="https://mdp.giustizia-amministrativa.it/visualizza/?..."
      const linkMatch = art.match(/href="([^"]*mdp\.giustizia-amministrativa\.it\/visualizza\/[^"]*)"/i);
      const urlOriginale = linkMatch ? linkMatch[1].replace(/&amp;/g, '&') : '';

      const sedeAttrMatch = art.match(/data-sede="([^"]*)"/i);
      const nrgAttrMatch = art.match(/data-nrg="([^"]*)"/i);
      const nomeFileMatch = urlOriginale.match(/nomeFile=([^&]+)/i);

      const schema = sedeAttrMatch ? sedeAttrMatch[1] : '';
      const nrg = nrgAttrMatch ? nrgAttrMatch[1] : '';
      const nomeFile = nomeFileMatch ? decodeURIComponent(nomeFileMatch[1]) : '';

      // 2. Tipologia, Sede, Sezione, Numero Provvedimento
      // e.g.: <b>SENTENZA</b> sede di <b>ROMA</b>, sezione <b>SEZIONE 5T</b>, numero provv.: <b>202616478</b>
      let tipologia = 'SENTENZA';
      let sede = 'ROMA';
      let sezione = '';
      let numeroProvvedimento = '';
      let annoProvvedimento = '';

      // Il tipo precede "sede di" e può essere composto, es. "ORDINANZA COLLEGIALE", "DECRETO CAUTELARE"
      const tipoMatch =
        art.match(/<b>([^<]+)<\/b>\s*sede\s+di/i) || art.match(/<b>((?:SENTENZA|ORDINANZA|DECRETO|PARERE|DECISIONE)[^<]*)<\/b>/i);
      if (tipoMatch) tipologia = tipoMatch[1].trim().toUpperCase();

      const sedeMatch = art.match(/sede\s+di\s+<b>([^<]+)<\/b>/i);
      if (sedeMatch) sede = sedeMatch[1].trim();

      const sezMatch = art.match(/sezione\s+<b>([^<]+)<\/b>/i);
      if (sezMatch) sezione = sezMatch[1].trim();

      const numProvvMatch = art.match(/numero\s+provv\.?\s*:\s*<b>([^<]+)<\/b>/i);
      if (numProvvMatch) {
        numeroProvvedimento = numProvvMatch[1].trim();
        annoProvvedimento = numeroProvvedimento.slice(0, 4);
      }

      // 3. Numero ricorso (RG)
      // Numero ricorso: <b>202607293</b>
      let numeroRicorso = nrg;
      let annoRicorso = nrg ? nrg.slice(0, 4) : '';
      const rgMatch = art.match(/Numero\s+ricorso\s*:\s*<b>([^<]+)<\/b>/i);
      if (rgMatch) {
        numeroRicorso = rgMatch[1].trim();
        annoRicorso = numeroRicorso.slice(0, 4);
      }

      // 4. ECLI
      // <b>ECLI:IT:TARLAZ:2026:16478SENT</b>
      let ecli = '';
      const ecliMatch = art.match(/<b>(ECLI:[^<]+)<\/b>/i);
      if (ecliMatch) ecli = ecliMatch[1].trim();

      // 5. Autorità
      let autorita = 'TAR';
      if (sede.toUpperCase().includes('CONSIGLIO') || schema.includes('cds')) {
        autorita = 'Consiglio di Stato';
      } else if (sede.toUpperCase().includes('CGA') || schema.includes('cga')) {
        autorita = 'CGA';
      } else {
        autorita = `TAR ${sede}`;
      }

      const id = `${schema || 'ga'}_${numeroRicorso || 'nr'}_${numeroProvvedimento || Math.random().toString(36).slice(2)}`;

      list.push({
        id,
        autorita,
        sede,
        sezione,
        tipologia,
        dataPubblicazione: this.state.params.fraseEsatta || getRomeDateString(),
        numeroProvvedimento,
        annoProvvedimento,
        numeroRicorso,
        annoRicorso,
        ecli,
        urlOriginale,
        nomeFile,
        schema,
        nrg,
        statusAcquisizione: 'in_corso',
        testoIntegrale: '',
        testoSezioni: {},
        documentoOriginaleHtml: '',
        formatoOriginale: '',
        dataPubblicazioneConforme: true,
        errore: null,
        dimensioneByte: 0,
        timestampDownload: '',
      });
    }

    return list;
  }

  private async processDocumentItem(item: GAPronuncia) {
    if (!item.urlOriginale) {
      item.statusAcquisizione = 'fallita';
      item.errore = 'URL del documento non disponibile nei risultati.';
      this.state.acquisizioniFallite++;
      this.state.erroriLinks.push({
        url: '',
        provv: `${item.tipologia} ${item.numeroProvvedimento}`,
        error: item.errore,
      });
      this.state.pronunce.push(item);
      return;
    }

    // Try fetching with retry
    let attempts = 0;
    const maxAttempts = 3;
    let lastError = '';

    while (attempts < maxAttempts) {
      attempts++;
      try {
        const res = await fetch(item.urlOriginale, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Referer': 'https://www.giustizia-amministrativa.it/web/guest/dcsnprr',
          },
        });

        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }

        const buffer = Buffer.from(await res.arrayBuffer());
        if (buffer.length === 0) {
          throw new Error('Documento vuoto');
        }
        const contentType = res.headers.get('content-type') || '';
        const isPdf = buffer.subarray(0, 5).toString('latin1') === '%PDF-' || contentType.includes('pdf');

        let parsed;
        if (isPdf) {
          const plain = await this.extractPdfText(buffer);
          parsed = this.buildDocumentText(plain, item);
          this.originals.set(item.id, { buffer, mime: 'application/pdf', ext: 'pdf' });
          item.formatoOriginale = 'pdf';
        } else {
          const html = buffer.toString('utf8');
          parsed = this.parseXmlDocument(html, item);
          this.originals.set(item.id, { buffer, mime: 'text/html; charset=utf-8', ext: 'html' });
          item.formatoOriginale = 'html';
        }

        item.dimensioneByte = buffer.length;
        item.timestampDownload = new Date().toISOString();
        item.testoIntegrale = parsed.fullText;
        item.testoSezioni = parsed.sections;
        if (parsed.dataPubblicazione) {
          item.dataPubblicazione = parsed.dataPubblicazione;
          const searched = this.state.params.fraseEsatta.trim();
          if (/^\d{2}\/\d{2}\/\d{4}$/.test(searched) && parsed.dataPubblicazione !== searched) {
            item.dataPubblicazioneConforme = false;
            this.addLog(
              'warn',
              `${item.tipologia} n. ${item.numeroProvvedimento} (${item.sede}): pubblicata il ${parsed.dataPubblicazione}, non il ${searched} (la data compare solo nel testo).`
            );
          }
        }
        if (parsed.fullText.length < 1500) {
          this.addLog('warn', `${item.tipologia} n. ${item.numeroProvvedimento}: testo estratto molto breve (documento scansionato?).`);
        }

        item.statusAcquisizione = 'completata';
        this.state.pronunceAcquisite++;
        this.addLog(
          'info',
          `Acquisito: ${item.tipologia} n. ${item.numeroProvvedimento} (${item.sede}) - ${item.formatoOriginale.toUpperCase()} ${item.dimensioneByte} byte, testo ${item.testoIntegrale.length} caratteri`
        );
        break;
      } catch (err: any) {
        lastError = err.message;
        if (attempts < maxAttempts) {
          await this.sleep(400 * attempts);
        }
      }
    }

    if (item.statusAcquisizione !== 'completata') {
      item.statusAcquisizione = 'fallita';
      item.errore = `Fallito dopo ${maxAttempts} tentativi: ${lastError}`;
      this.state.acquisizioniFallite++;
      this.state.erroriLinks.push({
        url: item.urlOriginale,
        provv: `${item.tipologia} ${item.numeroProvvedimento} (${item.sede})`,
        error: item.errore,
      });
      this.addLog('error', `Errore download ${item.tipologia} n. ${item.numeroProvvedimento}: ${item.errore}`);
    }

    this.state.pronunce.push(item);
  }

  private async extractPdfText(buffer: Buffer): Promise<string> {
    const pdf = await getDocumentProxy(new Uint8Array(buffer));
    const { text } = await extractText(pdf, { mergePages: false });
    const pages = Array.isArray(text) ? text : [text];
    // Rimuove l'intestazione "N. xxxx/AAAA REG.RIC." ripetuta in testa a ogni pagina, tranne la prima
    return pages
      .map((pageText, i) => {
        if (i === 0) return pageText;
        return pageText.replace(/^\s*N\.\s*\d+\s*\/\s*\d{4}\s+REG\.RIC\.\s*\n/, '');
      })
      .join('\n');
  }

  private htmlToText(html: string): string {
    const body = (html.match(/<body[^>]*>([\s\S]*)<\/body>/i) || [null, html])[1] as string;
    return body
      .replace(/<(script|style|head)[^>]*>[\s\S]*?<\/\1>/gi, '')
      .replace(/<img[^>]*>/gi, '')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|div|h:div|tr|h\d|li|table)>/gi, '\n')
      .replace(/<\/td>/gi, ' ')
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/\r\n/g, '\n')
      .replace(/[ \t]{2,}/g, ' ')
      .split('\n')
      .map((line) => line.trim())
      .join('\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  public parseXmlDocument(xml: string, fallbackItem: GAPronuncia): ParsedDocument {
    const cleanTags = (str: string) => this.htmlToText(`<body>${str}</body>`);

    // Formato XML strutturato (epigrafe/premessa/dispositivo...), se presente
    const extractTag = (tag: string) => {
      const regex = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i');
      const m = xml.match(regex);
      return m ? cleanTags(m[1]) : '';
    };
    const epigrafe = extractTag('epigrafe');
    const premessa = extractTag('premessa');
    const motivazione = extractTag('motivazione');
    const dispositivo = extractTag('dispositivo');
    const sottoscrizioni = extractTag('sottoscrizioni');

    if (epigrafe || premessa || motivazione || dispositivo) {
      const pubDateMatch = xml.match(/<dataPubblicazione>([^<]+)<\/dataPubblicazione>/i);
      const body: string[] = [];
      if (epigrafe) body.push(`[EPIGRAFE / INTESTAZIONE]\n${epigrafe}\n`);
      if (premessa) body.push(`[FATTO E DIRITTO]\n${premessa}\n`);
      if (motivazione) body.push(`[MOTIVAZIONE]\n${motivazione}\n`);
      if (dispositivo) body.push(`[DISPOSITIVO - P.Q.M.]\n${dispositivo}\n`);
      if (sottoscrizioni) body.push(`[SOTTOSCRIZIONI]\n${sottoscrizioni}\n`);
      const dataPubblicazione = pubDateMatch ? pubDateMatch[1].trim() : '';
      return {
        fullText: this.buildHeader(fallbackItem, dataPubblicazione) + body.join('\n'),
        sections: { epigrafe, premessa, motivazione, dispositivo, sottoscrizioni },
        dataPubblicazione,
      };
    }

    // Formato HTML impaginato (quello attualmente servito dal portale)
    // La dicitura "Pubblicato il" si trova nell'<head>, che htmlToText scarta
    const headDate = xml.match(/Pubblicato\s+il\s+(\d{2}\/\d{2}\/\d{4})/i);
    return this.buildDocumentText(this.htmlToText(xml), fallbackItem, headDate ? headDate[1] : undefined);
  }

  // Costruisce testo e sezioni a partire dal testo semplice del provvedimento (da PDF o HTML)
  private buildDocumentText(plain: string, item: GAPronuncia, dataNota?: string): ParsedDocument {
    const text = plain.replace(/\r\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    // Nei PDF la dicitura è in testa alla prima pagina: si cerca solo lì per non confonderla con provvedimenti citati
    const pubMatch = text.slice(0, 400).match(/Pubblicato\s+il\s+(\d{2}\/\d{2}\/\d{4})/i);
    const dataPubblicazione = dataNota || (pubMatch ? pubMatch[1] : '');

    const sections: ParsedDocument['sections'] = {};
    const pqm = text.search(/\n\s*P\.\s?Q\.\s?M\.?\s*\n/);
    if (pqm >= 0) {
      const tail = text.slice(pqm).trim();
      const firmaIdx = tail.search(/\n\s*Così deciso/i);
      sections.dispositivo = (firmaIdx > 0 ? tail.slice(0, firmaIdx) : tail).trim();
      if (firmaIdx > 0) sections.sottoscrizioni = tail.slice(firmaIdx).trim();
      sections.premessa = text.slice(0, pqm).trim();
    }

    return {
      fullText: this.buildHeader(item, dataPubblicazione) + text + '\n',
      sections,
      dataPubblicazione,
    };
  }

  private buildHeader(item: GAPronuncia, dataPubblicazione: string): string {
    const sep = '--------------------------------------------------------------------------------';
    const lines = [
      `AUTORITÀ: ${item.autorita}`,
      `SEDE: ${item.sede} | SEZIONE: ${item.sezione}`,
      `PROVVEDIMENTO: ${item.tipologia} N. ${item.numeroProvvedimento}/${item.annoProvvedimento}`,
      `REGISTRO GENERALE RICORSO: N. ${item.numeroRicorso}/${item.annoRicorso}`,
    ];
    if (dataPubblicazione) lines.push(`DATA PUBBLICAZIONE: ${dataPubblicazione}`);
    if (item.ecli) lines.push(`ECLI: ${item.ecli}`);
    lines.push(`URL ORIGINALE: ${item.urlOriginale}`);
    return `${sep}\n${lines.join('\n')}\n${sep}\n\n`;
  }

  public generateCsvIndex(): string {
    const headers = [
      'ID',
      'Autorita',
      'Sede',
      'Sezione',
      'Tipologia',
      'DataPubblicazione',
      'NumeroProvvedimento',
      'AnnoProvvedimento',
      'NumeroRicorsoRG',
      'AnnoRicorsoRG',
      'ECLI',
      'StatoAcquisizione',
      'DimensioneByte',
      'FormatoOriginale',
      'DataConformeRicerca',
      'NomeFileOriginale',
      'URL_Originale',
      'Errore',
    ];

    const escapeCsv = (val: string | number | null | undefined) => {
      if (val === null || val === undefined) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };

    const rows = this.state.pronunce.map((p) => [
      escapeCsv(p.id),
      escapeCsv(p.autorita),
      escapeCsv(p.sede),
      escapeCsv(p.sezione),
      escapeCsv(p.tipologia),
      escapeCsv(p.dataPubblicazione),
      escapeCsv(p.numeroProvvedimento),
      escapeCsv(p.annoProvvedimento),
      escapeCsv(p.numeroRicorso),
      escapeCsv(p.annoRicorso),
      escapeCsv(p.ecli),
      escapeCsv(p.statusAcquisizione),
      p.dimensioneByte,
      escapeCsv(p.formatoOriginale),
      escapeCsv(p.dataPubblicazioneConforme ? 'SI' : 'NO'),
      escapeCsv(p.nomeFile),
      escapeCsv(p.urlOriginale),
      escapeCsv(p.errore),
    ]);

    // Prepend UTF-8 BOM for Microsoft Excel compatibility
    return '\uFEFF' + [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');
  }

  public generateAuditReport(): AuditReport {
    const statsAuth: Record<string, number> = {};
    const statsTipo: Record<string, number> = {};

    for (const p of this.state.pronunce) {
      statsAuth[p.autorita] = (statsAuth[p.autorita] || 0) + 1;
      statsTipo[p.tipologia] = (statsTipo[p.tipologia] || 0) + 1;
    }

    const start = this.state.dataAvvio ? new Date(this.state.dataAvvio).getTime() : Date.now();
    const end = this.state.dataFine ? new Date(this.state.dataFine).getTime() : Date.now();
    const durataSecondi = Math.max(1, Math.round((end - start) / 1000));

    let esito: AuditReport['esitoFinale'] = 'COMPLETATA_CON_SUCCESSO';
    if (this.state.status === 'stopped') {
      esito = 'INTERROTTA';
    } else if (this.state.risultatiDichiaratiPortale === 0) {
      esito = 'NESSUN_RISULTATO';
    } else if (this.state.acquisizioniFallite > 0) {
      esito = 'COMPLETATA_CON_ERRORI';
    }

    return {
      titolo: 'Report di Audit Estrazione Massiva Giustizia Amministrativa',
      dataEstrazione: this.state.dataAvvio || new Date().toISOString(),
      parametriRicerca: this.state.params,
      numeroRisultatiDichiarati: this.state.risultatiDichiaratiPortale,
      numeroRisultatiIndividuati: this.state.risultatiIndividuati,
      numeroPronunceAcquisite: this.state.pronunceAcquisite,
      numeroAcquisizioniNonRiuscite: this.state.acquisizioniFallite,
      duplicatiIndividuati: this.state.duplicatiScartati,
      cartellaDestinazione: this.state.cartellaOutput,
      durataSecondi,
      collegamentiNonScaricati: this.state.erroriLinks,
      statistichePerAutorita: statsAuth,
      statistichePerTipologia: statsTipo,
      esitoFinale: esito,
    };
  }

  public generateMarkdownReport(): string {
    const report = this.generateAuditReport();
    const p = report.parametriRicerca;

    return `# Report di Estrazione Massiva — Giustizia Amministrativa

**Data Esecuzione**: ${new Date(report.dataEstrazione).toLocaleString('it-IT', { timeZone: 'Europe/Rome' })}
**Esito Finale**: \`${report.esitoFinale}\`
**Cartella Creata**: \`${report.cartellaDestinazione}\`
**Durata Operazione**: ${report.durataSecondi} secondi

---

## 1. Parametri di Ricerca Impostati
- **Parole chiave ("Che contenga tutte le seguenti parole")**: \`${p.paroleChiave}\`
- **Frase esatta ("Che contenga la seguente frase")**: \`${p.fraseEsatta}\`
- **Modalità di ricerca**: \`${p.modalitaRicerca === 'provv' ? 'Provvedimento' : 'Numero di registro generale'}\`
- **Risultati per pagina**: \`${p.risultatiPerPagina}\` (massimo consentito dalla piattaforma)
- **Filtri sede / tipologia**: \`${p.sede || 'Tutte'} / ${p.tipoProvvedimento || 'Tutte'}\`

---

## 2. Metriche di Riconciliazione e Coerenza
| Metrica | Valore | Note |
| :--- | :--- | :--- |
| **Risultati dichiarati dal portale** | **${report.numeroRisultatiDichiarati}** | Estratto dal contatore ufficiale del portale |
| **Risultati individuati e scansionati** | **${report.numeroRisultatiIndividuati}** | Scansione completa delle pagine |
| **Pronunce correttamente acquisite** | **${report.numeroPronunceAcquisite}** | Testo integrale e copia originale salvati |
| **Acquisizioni non riuscite (fallite)** | **${report.numeroAcquisizioniNonRiuscite}** | Errori di rete o mancata disponibilità |
| **Duplicati rilevati e scartati** | **${report.duplicatiIndividuati}** | Deduplicazione su (sede + RG + provvedimento) |

---

## 3. Ripartizione per Tipologia e Autorità
### Per Tipologia:
${Object.entries(report.statistichePerTipologia)
  .map(([tipo, count]) => `- **${tipo}**: ${count}`)
  .join('\n') || '- Nessuna'}

### Per Autorità Giudiziaria:
${Object.entries(report.statistichePerAutorita)
  .map(([auth, count]) => `- **${auth}**: ${count}`)
  .join('\n') || '- Nessuna'}

---

## 4. Elenco Collegamenti Pronunce Non Scaricate
${
  report.collegamentiNonScaricati.length === 0
    ? '✅ **Nessun errore riscontrato.** Tutti i documenti individuati sono stati acquisiti con successo.'
    : report.collegamentiNonScaricati
        .map((err, i) => `${i + 1}. **${err.provv}**\n   - URL: ${err.url}\n   - Errore: \`${err.error}\``)
        .join('\n\n')
}

---
*Generato automaticamente dall'Estrattore Massivo Giustizia Amministrativa.*
`;
  }

  public async generateZipArchive(): Promise<Buffer> {
    const zip = new JSZip();
    const rootFolder = zip.folder(this.state.cartellaOutput);
    if (!rootFolder) throw new Error('Impossibile creare la cartella root nello ZIP');

    const origFolder = rootFolder.folder('documenti_originali');
    const txtFolder = rootFolder.folder('testi_integrali');
    const pdfFolder = rootFolder.folder('documenti_pdf');

    // Add pronunce
    for (const p of this.state.pronunce) {
      if (p.statusAcquisizione !== 'completata') continue;

      const safeSede = p.sede.replace(/[^a-zA-Z0-9]/g, '_');
      const safeTipo = p.tipologia.replace(/[^a-zA-Z0-9]/g, '_');
      const safeNum = p.numeroProvvedimento || p.nrg;
      const baseFilename = `${safeTipo.toLowerCase()}_${safeNum}_${safeSede}`;

      // 1. Text file UTF-8
      if (txtFolder && p.testoIntegrale) {
        txtFolder.file(`${baseFilename}.txt`, p.testoIntegrale);
      }

      // 2. Original HTML / XML document
      const orig = this.originals.get(p.id);
      if (origFolder && orig) {
        origFolder.file(`${baseFilename}.${orig.ext}`, orig.buffer);
      }

      // 3. PDF: copia dell'originale se il portale fornisce un PDF, altrimenti PDF generato dal testo
      if (pdfFolder && orig?.ext === 'pdf') {
        pdfFolder.file(`${baseFilename}.pdf`, orig.buffer);
      } else if (pdfFolder && p.testoIntegrale) {
        try {
          const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
          const pageWidth = doc.internal.pageSize.getWidth();
          const pageHeight = doc.internal.pageSize.getHeight();
          const margin = 18;
          const contentWidth = pageWidth - margin * 2;

          doc.setFont('helvetica', 'bold');
          doc.setFontSize(13);
          doc.text('REPUBBLICA ITALIANA', pageWidth / 2, 16, { align: 'center' });
          doc.setFontSize(10);
          doc.text('IN NOME DEL POPOLO ITALIANO', pageWidth / 2, 22, { align: 'center' });

          doc.setFontSize(9);
          doc.setFont('helvetica', 'bold');
          doc.text(`${p.autorita} — Sede di ${p.sede}`, margin, 32);
          doc.setFont('helvetica', 'normal');
          doc.text(`Sezione: ${p.sezione || 'Ordinaria'} | ${p.tipologia} N. ${p.numeroProvvedimento}/${p.annoProvvedimento}`, margin, 37);
          doc.text(`Registro Generale (RG): N. ${p.numeroRicorso}/${p.annoRicorso} | Data: ${p.dataPubblicazione}`, margin, 42);
          if (p.ecli) doc.text(`ECLI: ${p.ecli}`, margin, 47);

          doc.setDrawColor(180, 180, 180);
          doc.setLineWidth(0.3);
          doc.line(margin, 51, pageWidth - margin, 51);

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8.5);
          const lines = doc.splitTextToSize(p.testoIntegrale, contentWidth);

          let y = 58;
          const lineHeight = 4.2;
          for (let i = 0; i < lines.length; i++) {
            if (y + lineHeight > pageHeight - margin) {
              doc.addPage();
              y = margin;
              doc.setFontSize(7.5);
              doc.setTextColor(130, 130, 130);
              doc.text(`${p.tipologia} n. ${p.numeroProvvedimento}/${p.annoProvvedimento} — ${p.autorita} (${p.sede})`, margin, y - 4);
              doc.setTextColor(0, 0, 0);
              doc.setFontSize(8.5);
            }
            doc.text(lines[i], margin, y);
            y += lineHeight;
          }

          const totalPages = doc.getNumberOfPages();
          for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
            doc.setPage(pageNum);
            doc.setFontSize(7.5);
            doc.setTextColor(140, 140, 140);
            doc.text(`Pagina ${pageNum} di ${totalPages} — Portale Giustizia Amministrativa`, pageWidth / 2, pageHeight - 8, { align: 'center' });
          }

          const pdfBuf = doc.output('arraybuffer');
          pdfFolder.file(`${baseFilename}.pdf`, pdfBuf);
        } catch (pdfErr) {
          console.error(`Errore generazione PDF server per ${p.id}:`, pdfErr);
        }
      }
    }

    // 3. General CSV index
    rootFolder.file('indice_pronunce.csv', this.generateCsvIndex());

    // 4. JSON Audit Report
    rootFolder.file('report_estrazione.json', JSON.stringify(this.generateAuditReport(), null, 2));

    // 5. Markdown Audit Report
    rootFolder.file('report_estrazione.md', this.generateMarkdownReport());

    return await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
  }

  public generateWindowsStandalonePackage(): { batScript: string; pythonScript: string; readme: string } {
    const batScript = `@echo off
chcp 65001 >nul
echo ========================================================
echo   ESTRATTORE MASSIVO PRONUNCE GIUSTIZIA AMMINISTRATIVA
echo ========================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERRORE] Python non e' installato o non e' presente nel PATH di Windows.
    echo Scarica e installa Python da https://www.python.org/
    echo Assicurati di selezionare "Add Python to PATH" durante l'installazione.
    pause
    exit /b 1
)

echo Controllo e installazione librerie necessarie (requests)...
pip install --quiet requests pypdf

echo.
echo Avvio script di estrazione automatica...
python estrattore_ga.py

echo.
echo Operazione completata. I documenti sono salvati nella cartella Sentenze_GA_*
pause
`;

    const pythonScript = `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Estrattore massivo delle pronunce di Giustizia Amministrativa
Portale: https://www.giustizia-amministrativa.it/de/dcsnprr
"""

import sys
import os
import re
import time
import csv
import json
from datetime import datetime
import zoneinfo
import requests

ZONE_ROME = zoneinfo.ZoneInfo("Europe/Rome")

def get_today_rome():
    now = datetime.now(ZONE_ROME)
    return now.strftime("%d/%m/%Y")

def get_folder_name(date_str):
    parts = date_str.split('/')
    if len(parts) == 3:
        return f"Sentenze_GA_{parts[2]}-{parts[1]}-{parts[0]}"
    return f"Sentenze_GA_{date_str.replace('/', '_')}"

def clean_tags(html):
    if not html:
        return ""
    text = re.sub(r'<(style|script)[^>]*>.*?</\\1>', '', html, flags=re.I | re.S)
    text = re.sub(r'<br\\s*/?>', '\\n', text, flags=re.I)
    text = re.sub(r'</h:div>', '\\n', text, flags=re.I)
    text = re.sub(r'</p>', '\\n\\n', text, flags=re.I)
    text = re.sub(r'</?[^>]+>', '', text)
    text = text.replace('&nbsp;', ' ').replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&#39;', "'")
    return re.sub(r'\\n{3,}', '\\n\\n', text).strip()

def run_extraction(parole_chiave="gara", frase_data=None):
    if not frase_data:
        frase_data = get_today_rome()

    folder = get_folder_name(frase_data)
    dir_orig = os.path.join(folder, "documenti_originali")
    dir_txt = os.path.join(folder, "testi_integrali")
    os.makedirs(dir_orig, exist_ok=True)
    os.makedirs(dir_txt, exist_ok=True)

    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    })

    print(f"[*] Connessione al portale Giustizia Amministrativa (dcsnprr)...")
    res_init = session.get("https://www.giustizia-amministrativa.it/web/guest/dcsnprr")
    if res_init.status_code != 200:
        print(f"[!] Errore connessione iniziale: {res_init.status_code}")
        return

    form_match = re.search(r'<form[^>]+class="form-provvedimenti"[^>]+action="([^"]+)"', res_init.text)
    if not form_match:
        print("[!] Form di ricerca non trovato.")
        return

    action_url = form_match.group(1).replace('&amp;', '&')
    inst_match = re.search(r'INSTANCE_([a-zA-Z0-9]+)', action_url)
    inst = inst_match.group(1) if inst_match else "XKc17mrB8J10"
    pfx = f"_decisioni_pareri_web_DecisioniPareriWebPortlet_INSTANCE_{inst}_"

    post_data = {
        f"{pfx}formDate": str(int(time.time() * 1000)),
        f"{pfx}isAdvancedSearch": "true",
        f"{pfx}searchAllWords": parole_chiave,
        f"{pfx}searchPhrase": frase_data,
        f"{pfx}asSearchMode": "provv",
        f"{pfx}searchModeRadio": "provv",
        f"{pfx}pageSize": "60",
        f"{pfx}findBtn": "true"
    }

    print(f"[*] Esecuzione ricerca: parole='{parole_chiave}', frase='{frase_data}', pageSize=60...")
    res_search = session.post(action_url, data=post_data)
    if res_search.status_code != 200:
        print(f"[!] Errore HTTP ricerca: {res_search.status_code}")
        return

    html = res_search.text
    tot_match = re.search(r'Risultati\\s+da\\s+\\d+\\s+a\\s+\\d+\\s+di\\s+(\\d+)\\s+totali', html)
    total_results = int(tot_match.group(1)) if tot_match else 0
    print(f"[+] Risultati totali dichiarati: {total_results}")

    if total_results == 0:
        print("[*] Nessun provvedimento trovato per i parametri specificati.")
        return

    total_pages = (total_results + 59) // 60
    downloaded = 0
    failed = 0
    seen = set()
    records = []

    for page in range(1, total_pages + 1):
        print(f"\\n[*] Pagina {page} di {total_pages}...")
        if page > 1:
            p_url = f"{action_url}&{pfx}searchAllWords={parole_chiave}&{pfx}searchPhrase={frase_data}&{pfx}pageSize=60&{pfx}delta=60&{pfx}cur={page}&{pfx}changePage=true&{pfx}asSearchMode=provv"
            p_res = session.get(p_url)
            html = p_res.text if p_res.status_code == 200 else ""

        articles = re.findall(r'<article\\s+class="ricerca--item">([\\s\\S]*?)</article>', html)
        for art in articles:
            if "col-pagination" in art or "Risultati da" in art:
                continue

            link_m = re.search(r'href="([^"]*mdp\\.giustizia-amministrativa\\.it/visualizza/[^"]*)"', art)
            url_orig = link_m.group(1).replace('&amp;', '&') if link_m else ""
            num_m = re.search(r'numero\\s+provv\\.?\\s*:\\s*<b>([^<]+)</b>', art)
            num_provv = num_m.group(1).strip() if num_m else "provv"
            sede_m = re.search(r'sede\\s+di\\s+<b>([^<]+)</b>', art)
            sede = sede_m.group(1).strip() if sede_m else "SEDE"
            tipo_m = re.search(r'<b>([^<]+)</b>\\s*sede\\s+di', art)
            tipo = tipo_m.group(1).strip().upper() if tipo_m else "SENTENZA"
            rg_m = re.search(r'Numero\\s+ricorso\\s*:\\s*<b>([^<]+)</b>', art)
            rg = rg_m.group(1).strip() if rg_m else ""
            ecli_m = re.search(r'<b>(ECLI:[^<]+)</b>', art)
            ecli = ecli_m.group(1).strip() if ecli_m else ""

            uid = f"{sede}_{rg}_{num_provv}"
            if uid in seen:
                continue
            seen.add(uid)

            if not url_orig:
                failed += 1
                continue

            try:
                doc_res = session.get(url_orig, timeout=20)
                if doc_res.status_code == 200:
                    base_name = f"{sede.replace(' ', '_')}_{tipo.replace(' ', '_')}_{num_provv}_RG{rg}"
                    if doc_res.content[:5] == b"%PDF-":
                        # Il portale fornisce molti provvedimenti in PDF: si salva l'originale binario
                        with open(os.path.join(dir_orig, f"{base_name}.pdf"), "wb") as f:
                            f.write(doc_res.content)
                        try:
                            from pypdf import PdfReader
                            reader = PdfReader(os.path.join(dir_orig, f"{base_name}.pdf"))
                            clean_text = "\\n".join((page.extract_text() or "") for page in reader.pages)
                        except Exception as pdf_err:
                            clean_text = f"[Testo non estratto dal PDF: {pdf_err}]"
                    else:
                        raw_content = doc_res.content.decode("utf-8", errors="replace")
                        clean_text = clean_tags(raw_content)
                        with open(os.path.join(dir_orig, f"{base_name}.html"), "w", encoding="utf-8") as f:
                            f.write(raw_content)
                    with open(os.path.join(dir_txt, f"{base_name}.txt"), "w", encoding="utf-8") as f:
                        f.write(clean_text)

                    downloaded += 1
                    print(f"  [+] Scaricato: {tipo} n. {num_provv} ({sede})")
                    records.append({
                        "Autorita": f"TAR {sede}", "Sede": sede, "Tipologia": tipo,
                        "NumeroProvvedimento": num_provv, "NumeroRG": rg,
                        "ECLI": ecli, "URL": url_orig, "Stato": "OK"
                    })
                else:
                    failed += 1
                    print(f"  [-] Errore download {num_provv}: HTTP {doc_res.status_code}")
            except Exception as e:
                failed += 1
                print(f"  [-] Eccezione download {num_provv}: {e}")

            time.sleep(0.15)

    # Save CSV Index
    csv_file = os.path.join(folder, "indice_pronunce.csv")
    if records:
        with open(csv_file, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=records[0].keys(), delimiter=";")
            writer.writeheader()
            writer.writerows(records)

    # Save Report
    report = {
        "data_estrazione": datetime.now(ZONE_ROME).isoformat(),
        "parole_chiave": parole_chiave,
        "frase_data": frase_data,
        "dichiarati": total_results,
        "acquisiti": downloaded,
        "falliti": failed,
        "cartella": folder
    }
    with open(os.path.join(folder, "report_estrazione.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\\n========================================================")
    print(f"Estrazione completata! Totale acquisiti: {downloaded}/{total_results}. Errori: {failed}.")
    print(f"File salvati in: {os.path.abspath(folder)}")
    print(f"========================================================")

if __name__ == "__main__":
    kw = sys.argv[1] if len(sys.argv) > 1 else "gara"
    dt = sys.argv[2] if len(sys.argv) > 2 else get_today_rome()
    run_extraction(kw, dt)
`;

    const readme = `# Istruzioni Esecuzione Estrattore GA su Windows

Questa cartella contiene l'applicazione standalone per Windows.

## Prerequisiti
1. Python 3.9 o superiore installato sul computer Windows (https://www.python.org/).
2. Assicurarsi di aver spuntato "Add Python to PATH" durante l'installazione di Python.

## Modalità di avvio veloce
1. Fare doppio clic sul file **\`run_estrazione.bat\`**.
2. Il programma installerà automaticamente le dipendenze leggere (\`requests\`) ed eseguirà l'estrazione con i parametri standard ("gara", data odierna Rome).
3. I file scaricati saranno organizzati nella cartella \`Sentenze_GA_AAAA-MM-GG\`:
   - \`documenti_originali/\`: Copia HTML/XML originale di ogni pronuncia
   - \`testi_integrali/\`: Testo integrale UTF-8 pulito (per AI / RAG / analisi)
   - \`indice_pronunce.csv\`: Tabella metadati per Microsoft Excel
   - \`report_estrazione.json\`: Report di audit certificato con statistiche
`;

    return { batScript, pythonScript, readme };
  }
}

export const scraperEngine = new ScraperEngine();
