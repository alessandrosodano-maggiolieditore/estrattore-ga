/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.js';
import { SearchForm } from './components/SearchForm.js';
import { ProgressDashboard } from './components/ProgressDashboard.js';
import { DocumentExplorer } from './components/DocumentExplorer.js';
import { DocumentViewerModal } from './components/DocumentViewerModal.js';
import { ExportArchiveView } from './components/ExportArchiveView.js';
import { SchedulerView } from './components/SchedulerView.js';
import { DiagnosticsView } from './components/DiagnosticsView.js';
import { ExtractionParams, ExtractionState, GAPronuncia } from './types/scraper.js';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'search' | 'documents' | 'export' | 'scheduler' | 'diagnostics'>('search');
  const [selectedDocument, setSelectedDocument] = useState<GAPronuncia | null>(null);

  const [state, setState] = useState<ExtractionState>({
    jobId: '',
    status: 'idle',
    params: {
      paroleChiave: 'gara',
      fraseEsatta: new Intl.DateTimeFormat('it-IT', {
        timeZone: 'Europe/Rome',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      }).format(new Date()),
      tipoProvvedimento: '',
      sede: '',
      modalitaRicerca: 'provv',
      risultatiPerPagina: 60,
    },
    dataAvvio: null,
    dataFine: null,
    risultatiDichiaratiPortale: 0,
    risultatiIndividuati: 0,
    pronunceAcquisite: 0,
    acquisizioniFallite: 0,
    duplicatiScartati: 0,
    paginaCorrente: 0,
    totalePagine: 0,
    percentuale: 0,
    velocitaDocSec: 0,
    pronunce: [],
    erroriLinks: [],
    logs: [],
    cartellaOutput: 'Sentenze_GA',
  });

  // Connect to SSE stream and initial fetch
  useEffect(() => {
    // 1. Initial status fetch
    fetch('/api/search/status')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.params) {
          setState(data);
        }
      })
      .catch((err) => console.error('Error fetching initial status:', err));

    // 2. Real-time Server-Sent Events
    let eventSource: EventSource | null = null;
    try {
      eventSource = new EventSource('/api/search/events');
      eventSource.onmessage = (event) => {
        try {
          const updatedState = JSON.parse(event.data);
          setState(updatedState);
        } catch (e) {
          console.error('Error parsing SSE data:', e);
        }
      };
      eventSource.onerror = () => {
        // SSE fallback is handled automatically by browser reconnect
      };
    } catch (e) {
      console.error('Error connecting to SSE:', e);
    }

    return () => {
      if (eventSource) {
        eventSource.close();
      }
    };
  }, []);

  const handleStart = async (params: ExtractionParams) => {
    try {
      const res = await fetch('/api/search/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (!data.success) {
        alert(data.message || 'Errore avvio estrazione.');
      }
    } catch (err: any) {
      alert('Errore di connessione: ' + err.message);
    }
  };

  const handlePause = async () => {
    try {
      await fetch('/api/search/pause', { method: 'POST' });
    } catch (err: any) {
      console.error('Error pausing:', err);
    }
  };

  const handleResume = async () => {
    try {
      await fetch('/api/search/resume', { method: 'POST' });
    } catch (err: any) {
      console.error('Error resuming:', err);
    }
  };

  const handleStop = async () => {
    try {
      await fetch('/api/search/stop', { method: 'POST' });
    } catch (err: any) {
      console.error('Error stopping:', err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        state={state}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {currentTab === 'search' && (
          <div className="space-y-6">
            <SearchForm
              state={state}
              onStart={handleStart}
              onPause={handlePause}
              onResume={handleResume}
              onStop={handleStop}
              onViewDocuments={() => setCurrentTab('documents')}
            />

            <ProgressDashboard state={state} />
          </div>
        )}

        {currentTab === 'documents' && (
          <div className="space-y-6">
            <DocumentExplorer
              documents={state.pronunce}
              onSelectDocument={setSelectedDocument}
            />
          </div>
        )}

        {currentTab === 'export' && (
          <div className="space-y-6">
            <ExportArchiveView state={state} />
          </div>
        )}

        {currentTab === 'scheduler' && (
          <div className="space-y-6">
            <SchedulerView />
          </div>
        )}

        {currentTab === 'diagnostics' && (
          <div className="space-y-6">
            <DiagnosticsView />
          </div>
        )}
      </main>

      {/* Modal Document Viewer */}
      {selectedDocument && (
        <DocumentViewerModal
          document={selectedDocument}
          onClose={() => setSelectedDocument(null)}
        />
      )}

      {/* Quiet Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">Estrattore Massivo Pronunce GA</span>
            <span>·</span>
            <span>Conforme alle specifiche di Decisioni e Pareri (dcsnprr)</span>
          </div>
          <div className="flex items-center gap-4">
            <a
              href="https://www.giustizia-amministrativa.it"
              target="_blank"
              rel="noreferrer"
              className="hover:text-slate-300 transition-colors"
            >
              Portale Giustizia Amministrativa
            </a>
            <a
              href="https://mdp.giustizia-amministrativa.it"
              target="_blank"
              rel="noreferrer"
              className="hover:text-slate-300 transition-colors"
            >
              Repository Documentale MDP
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
