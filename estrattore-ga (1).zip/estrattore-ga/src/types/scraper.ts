/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface GAPronuncia {
  id: string; // e.g. tar_rm_202607293_202616478
  autorita: string; // 'TAR', 'Consiglio di Stato', 'CGA'
  sede: string; // 'ROMA', 'MILANO', etc.
  sezione: string; // 'SEZIONE 5T', etc.
  tipologia: string; // 'SENTENZA', 'ORDINANZA', 'DECRETO', 'PARERE'
  dataPubblicazione: string; // GG/MM/AAAA
  numeroProvvedimento: string; // e.g. '202616478'
  annoProvvedimento: string; // e.g. '2026'
  numeroRicorso: string; // e.g. '202607293'
  annoRicorso: string; // e.g. '2026'
  ecli: string; // e.g. 'ECLI:IT:TARLAZ:2026:16478SENT'
  urlOriginale: string;
  nomeFile: string; // e.g. 202616478_01.html
  schema: string; // e.g. tar_rm
  nrg: string; // e.g. 202607293
  statusAcquisizione: 'completata' | 'fallita' | 'in_corso' | 'duplicato_ignorato';
  testoIntegrale: string;
  testoSezioni: {
    epigrafe?: string;
    premessa?: string;
    motivazione?: string;
    fatto?: string;
    diritto?: string;
    dispositivo?: string;
    sottoscrizioni?: string;
  };
  documentoOriginaleHtml: string; // Popolato solo da /api/documents/:id per i documenti HTML
  formatoOriginale: 'pdf' | 'html' | '';
  dataPubblicazioneConforme: boolean; // false se la data di pubblicazione letta nel documento differisce dalla data cercata
  errore: string | null;
  dimensioneByte: number;
  timestampDownload: string;
}

export interface ExtractionParams {
  paroleChiave: string; // Default: 'gara'
  fraseEsatta: string; // Default: GG/MM/AAAA (Rome timezone)
  tipoProvvedimento: string; // Empty = all
  sede: string; // Empty = all
  modalitaRicerca: 'provv' | 'nrg'; // Default: 'provv'
  risultatiPerPagina: number; // Default: 60 (max allowed)
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  message: string;
}

export interface ExtractionState {
  jobId: string;
  status: 'idle' | 'running' | 'paused' | 'completed' | 'stopped' | 'failed';
  params: ExtractionParams;
  dataAvvio: string | null;
  dataFine: string | null;
  risultatiDichiaratiPortale: number;
  risultatiIndividuati: number;
  pronunceAcquisite: number;
  acquisizioniFallite: number;
  duplicatiScartati: number;
  paginaCorrente: number;
  totalePagine: number;
  percentuale: number;
  velocitaDocSec: number;
  pronunce: GAPronuncia[];
  erroriLinks: { url: string; provv: string; error: string }[];
  logs: LogEntry[];
  cartellaOutput: string;
}

export interface AuditReport {
  titolo: string;
  dataEstrazione: string;
  parametriRicerca: ExtractionParams;
  numeroRisultatiDichiarati: number;
  numeroRisultatiIndividuati: number;
  numeroPronunceAcquisite: number;
  numeroAcquisizioniNonRiuscite: number;
  duplicatiIndividuati: number;
  cartellaDestinazione: string;
  durataSecondi: number;
  collegamentiNonScaricati: { url: string; provv: string; error: string }[];
  statistichePerAutorita: Record<string, number>;
  statistichePerTipologia: Record<string, number>;
  esitoFinale: 'COMPLETATA_CON_SUCCESSO' | 'COMPLETATA_CON_ERRORI' | 'INTERROTTA' | 'NESSUN_RISULTATO';
}

export interface ScheduleConfig {
  attivo: boolean;
  ora: string; // HH:MM in Europe/Rome (default 08:00)
  paroleChiave: string;
  usaDataCorrente: boolean;
  ultimaEsecuzione: string | null;
  prossimaEsecuzione: string | null;
  statoUltimaEsecuzione: string | null;
}
