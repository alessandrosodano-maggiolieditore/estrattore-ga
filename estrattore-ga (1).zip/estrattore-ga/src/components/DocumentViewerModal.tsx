/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { X, Copy, Download, ExternalLink, FileText, Code, FileCheck, Info, Printer } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { GAPronuncia } from '../types/scraper.js';

interface DocumentViewerModalProps {
  document: GAPronuncia | null;
  onClose: () => void;
}

export const DocumentViewerModal: React.FC<DocumentViewerModalProps> = ({ document: summary, onClose }) => {
  const [activeTab, setActiveTab] = useState<'txt' | 'html' | 'pdf' | 'meta'>('txt');
  const [copied, setCopied] = useState(false);
  const [full, setFull] = useState<GAPronuncia | null>(null);

  // Lo stato in tempo reale non contiene i testi: si caricano dal server all'apertura
  useEffect(() => {
    setFull(null);
    if (!summary) return;
    let cancelled = false;
    fetch(`/api/documents/${encodeURIComponent(summary.id)}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setFull(data);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [summary?.id]);

  if (!summary) return null;
  const document = full && full.id === summary.id ? full : summary;
  const originalUrl = `/api/documents/${encodeURIComponent(document.id)}/original`;
  const originalLabel = document.formatoOriginale === 'pdf' ? 'PDF' : 'HTML';

  const copyText = () => {
    navigator.clipboard.writeText(document.testoIntegrale || 'Nessun testo disponibile');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadTxt = () => {
    const blob = new Blob([document.testoIntegrale || ''], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${document.sede}_${document.tipologia}_${document.numeroProvvedimento}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadOriginal = () => {
    window.location.href = `${originalUrl}?download=1`;
  };

  const generateAndDownloadPdf = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const title = `${document.autorita} - ${document.tipologia} N. ${document.numeroProvvedimento}/${document.annoProvvedimento}`;
    const subtitle = `Sede: ${document.sede} | Sezione: ${document.sezione} | Ricorso RG: ${document.numeroRicorso}`;
    const ecli = document.ecli ? `ECLI: ${document.ecli}` : '';

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('REPUBBLICA ITALIANA', 105, 18, { align: 'center' });
    doc.setFontSize(11);
    doc.text('IN NOME DEL POPOLO ITALIANO', 105, 24, { align: 'center' });

    doc.setFontSize(10);
    doc.text(title, 20, 34);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(subtitle, 20, 40);
    if (ecli) doc.text(ecli, 20, 46);

    doc.setLineWidth(0.3);
    doc.line(20, 50, 190, 50);

    const bodyText = document.testoIntegrale || 'Testo non disponibile';
    const splitText = doc.splitTextToSize(bodyText, 170);

    let cursorY = 56;
    for (let i = 0; i < splitText.length; i++) {
      if (cursorY > 280) {
        doc.addPage();
        cursorY = 20;
      }
      doc.text(splitText[i], 20, cursorY);
      cursorY += 5;
    }

    doc.save(`${document.sede}_${document.tipologia}_${document.numeroProvvedimento}.pdf`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-hidden">
      <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-5xl h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex-1 min-w-0 pr-4">
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <span className="font-semibold text-blue-400">{document.autorita}</span>
              <span>·</span>
              <span>Sede: {document.sede}</span>
              <span>·</span>
              <span>Sezione: {document.sezione || 'Non specificata'}</span>
            </div>
            <h2 className="text-base font-bold text-white truncate">
              {document.tipologia} n. {document.numeroProvvedimento}/{document.annoProvvedimento}
              <span className="font-normal text-slate-400 ml-2 text-xs">
                (Ricorso RG: {document.numeroRicorso}/{document.annoRicorso})
              </span>
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Switcher & Quick Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-2.5 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('txt')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-colors ${
                activeTab === 'txt'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white bg-slate-800/60'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Testo Integrale (TXT)</span>
            </button>

            <button
              onClick={() => setActiveTab('html')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-colors ${
                activeTab === 'html'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white bg-slate-800/60'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>Documento Originale ({originalLabel})</span>
            </button>

            <button
              onClick={() => setActiveTab('pdf')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-colors ${
                activeTab === 'pdf'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white bg-slate-800/60'
              }`}
            >
              <FileCheck className="w-3.5 h-3.5" />
              <span>Anteprima / PDF</span>
            </button>

            <button
              onClick={() => setActiveTab('meta')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-colors ${
                activeTab === 'meta'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white bg-slate-800/60'
              }`}
            >
              <Info className="w-3.5 h-3.5" />
              <span>Metadati & ECLI</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {activeTab === 'txt' && (
              <>
                <button
                  onClick={copyText}
                  className="flex items-center gap-1 px-3 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copiato!' : 'Copia Testo'}</span>
                </button>
                <button
                  onClick={downloadTxt}
                  className="flex items-center gap-1 px-3 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Salva TXT</span>
                </button>
              </>
            )}

            {activeTab === 'html' && document.formatoOriginale && (
              <button
                onClick={downloadOriginal}
                className="flex items-center gap-1 px-3 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Salva {originalLabel}</span>
              </button>
            )}

            {activeTab === 'pdf' && (
              <button
                onClick={generateAndDownloadPdf}
                className="flex items-center gap-1 px-3 py-1 text-xs text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors cursor-pointer font-semibold shadow-sm"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Scarica PDF Stampabile</span>
              </button>
            )}

            {document.urlOriginale && (
              <a
                href={document.urlOriginale}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 px-3 py-1 text-xs text-blue-400 hover:text-blue-300 bg-slate-800/80 rounded-lg border border-slate-700 transition-colors"
              >
                <span>Apri su portale GA</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-950 font-sans text-sm">
          {activeTab === 'txt' && (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 max-w-4xl mx-auto shadow-inner">
              <pre className="whitespace-pre-wrap font-mono text-xs leading-relaxed text-slate-200 selection:bg-blue-600 selection:text-white">
                {document.testoIntegrale || 'Nessun testo disponibile per questa pronuncia.'}
              </pre>
            </div>
          )}

          {activeTab === 'html' && (
            <div className="bg-white rounded-lg max-w-4xl mx-auto shadow-2xl h-full min-h-[60vh] overflow-hidden">
              {document.formatoOriginale ? (
                <iframe
                  key={document.id}
                  src={originalUrl}
                  title="Documento originale"
                  className="w-full h-full border-0"
                  {...(document.formatoOriginale === 'html' ? { sandbox: '' } : {})}
                />
              ) : (
                <div className="text-slate-500 text-center py-12 font-sans">
                  Documento originale non disponibile.
                </div>
              )}
            </div>
          )}

          {activeTab === 'pdf' && (
            <div className="bg-white text-slate-900 rounded-lg p-10 max-w-3xl mx-auto shadow-2xl min-h-full font-serif border border-slate-200">
              <div className="text-center border-b border-slate-300 pb-4 mb-6">
                <div className="text-xs uppercase tracking-widest text-slate-500 font-semibold mb-1">
                  Repubblica Italiana
                </div>
                <div className="text-xs uppercase tracking-wider text-slate-700 font-bold mb-3">
                  In Nome del Popolo Italiano
                </div>
                <div className="text-base font-bold text-slate-900">
                  {document.autorita} — {document.sede}
                </div>
                <div className="text-xs text-slate-600 mt-1">
                  {document.tipologia} n. {document.numeroProvvedimento}/{document.annoProvvedimento} · Ricorso RG: {document.numeroRicorso}
                </div>
                {document.ecli && (
                  <div className="text-[11px] font-mono text-slate-500 mt-1">
                    {document.ecli}
                  </div>
                )}
              </div>

              <div className="text-xs leading-relaxed text-slate-800 whitespace-pre-wrap font-sans">
                {document.testoIntegrale}
              </div>

              <div className="mt-8 pt-4 border-t border-slate-300 text-center">
                <button
                  onClick={generateAndDownloadPdf}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors shadow-md cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Scarica PDF generato dal testo</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'meta' && (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 max-w-3xl mx-auto space-y-4">
              <h3 className="text-sm font-bold text-white pb-2 border-b border-slate-800">
                Scheda Metadati Giurisdizionali
              </h3>
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <dt className="text-slate-500 font-medium">Autorità Giudiziaria</dt>
                  <dd className="text-white font-semibold mt-0.5">{document.autorita}</dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <dt className="text-slate-500 font-medium">Sede e Sezione</dt>
                  <dd className="text-white font-semibold mt-0.5">{document.sede} - {document.sezione}</dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <dt className="text-slate-500 font-medium">Tipologia Provvedimento</dt>
                  <dd className="text-white font-semibold mt-0.5">{document.tipologia}</dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <dt className="text-slate-500 font-medium">Numero e Anno Provvedimento</dt>
                  <dd className="text-white font-mono font-semibold mt-0.5">{document.numeroProvvedimento} / {document.annoProvvedimento}</dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <dt className="text-slate-500 font-medium">Numero Registro Generale (RG)</dt>
                  <dd className="text-white font-mono font-semibold mt-0.5">{document.numeroRicorso} / {document.annoRicorso}</dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <dt className="text-slate-500 font-medium">Data di Pubblicazione</dt>
                  <dd className="text-white font-mono font-semibold mt-0.5">{document.dataPubblicazione}</dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 sm:col-span-2">
                  <dt className="text-slate-500 font-medium">Identificativo ECLI</dt>
                  <dd className="text-blue-400 font-mono font-semibold mt-0.5">{document.ecli || 'Non presente'}</dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 sm:col-span-2">
                  <dt className="text-slate-500 font-medium">URL Originale di visualizzazione</dt>
                  <dd className="text-slate-300 font-mono text-[11px] mt-0.5 break-all">
                    <a href={document.urlOriginale} target="_blank" rel="noreferrer" className="text-blue-400 underline">
                      {document.urlOriginale}
                    </a>
                  </dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <dt className="text-slate-500 font-medium">Dimensione file scaricato</dt>
                  <dd className="text-slate-300 font-mono mt-0.5">{document.dimensioneByte} byte</dd>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <dt className="text-slate-500 font-medium">Timestamp Acquisizione</dt>
                  <dd className="text-slate-300 font-mono mt-0.5">{document.timestampDownload || 'Non registrato'}</dd>
                </div>
              </dl>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
