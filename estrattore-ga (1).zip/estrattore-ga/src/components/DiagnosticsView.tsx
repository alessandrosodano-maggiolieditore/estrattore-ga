/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Activity, CheckCircle2, XCircle, RefreshCw, Server, ShieldCheck, Database, Globe } from 'lucide-react';

export const DiagnosticsView: React.FC = () => {
  const [running, setRunning] = useState(false);
  const [data, setData] = useState<any>(null);

  const runDiagnostics = async () => {
    setRunning(true);
    try {
      const res = await fetch('/api/diagnostics', { method: 'POST' });
      const result = await res.json();
      setData(result);
    } catch (err: any) {
      setData({ error: err.message });
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl max-w-4xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-400" />
            <span>Diagnostica Portale Giustizia Amministrativa</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Test di connessione dal vivo e verifica formale dei selettori, dei token Liferay e degli endpoint di download.
          </p>
        </div>

        <button
          onClick={runDiagnostics}
          disabled={running}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors cursor-pointer disabled:opacity-60"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${running ? 'animate-spin' : ''}`} />
          <span>{running ? 'Verifica in corso...' : 'Esegui Test di Connettività'}</span>
        </button>
      </div>

      {/* Verification Matrix */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Elenco Verifiche Funzionali di Sistema
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {/* Check 1 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">1. Raggiungibilità Portale Ufficiale</div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                Endpoint: <code>https://www.giustizia-amministrativa.it/web/guest/dcsnprr</code>
              </div>
            </div>
          </div>

          {/* Check 2 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">2. Negoziazione Sessione e Cookie Liferay</div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                Acquisizione corretta di <code>JSESSIONID</code> e <code>COOKIE_SUPPORT</code>
              </div>
            </div>
          </div>

          {/* Check 3 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">3. Selettori e Token di Sicurezza p_auth</div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                Riconoscimento dinamico dell'istanza portlet e firma autorizzativa del form
              </div>
            </div>
          </div>

          {/* Check 4 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">4. Paginazione Sistematica (delta=60, cur=N)</div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                Attraversamento oltre i primi 20 risultati fino all'esaurimento effettivo
              </div>
            </div>
          </div>

          {/* Check 5 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">5. Acquisizione Repository Documentale (mdp)</div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                Apertura pronunce su <code>mdp.giustizia-amministrativa.it/visualizza/</code>
              </div>
            </div>
          </div>

          {/* Check 6 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">6. Parsing Strutturato e Formati Output</div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                Generazione automatica di TXT UTF-8, HTML originale, PDF, CSV e Report di Audit
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Check Output */}
      {data && (
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs space-y-2">
          <div className="text-slate-400 font-bold mb-1 flex items-center justify-between">
            <span>Esito Ultimo Test di Connettività:</span>
            <span className="text-slate-500 font-normal">{data.timestamp}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div>
              <span className="text-slate-500">Stato HTTP Portale:</span>{' '}
              <span className={data.portalReachability ? 'text-emerald-400' : 'text-red-400'}>
                {data.portalHttpStatus || 'Non raggiungibile'} ({data.portalLatencyMs} ms)
              </span>
            </div>
            <div>
              <span className="text-slate-500">Cookie di Sessione:</span>{' '}
              <span className={data.sessionCookieAcquired ? 'text-emerald-400' : 'text-red-400'}>
                {data.sessionCookieAcquired ? 'Rilasciati regolarmente' : 'Non rilevati'}
              </span>
            </div>
            <div>
              <span className="text-slate-500">Form Ricerca Avanzata:</span>{' '}
              <span className={data.formActionFound ? 'text-emerald-400' : 'text-red-400'}>
                {data.formActionFound ? 'Presente nel DOM' : 'Non trovato'}
              </span>
            </div>
            <div>
              <span className="text-slate-500">Token di Sicurezza p_auth:</span>{' '}
              <span className={data.pAuthTokenFound ? 'text-emerald-400' : 'text-amber-400'}>
                {data.pAuthTokenFound ? 'Valido e negoziato' : 'Non presente'}
              </span>
            </div>
          </div>

          {data.formActionUrl && (
            <div className="text-[10px] text-slate-500 break-all pt-1 border-t border-slate-900">
              Form Action: {data.formActionUrl}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
