/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Download,
  FolderArchive,
  FileSpreadsheet,
  FileText,
  FileCode,
  CheckCircle2,
  ShieldCheck,
  Terminal,
  AlertCircle,
  Loader2,
  FileCheck,
} from 'lucide-react';
import { ExtractionState } from '../types/scraper.js';
import { downloadSentenzeZipClient } from '../utils/zipClientExporter.js';

interface ExportArchiveViewProps {
  state: ExtractionState;
}

export const ExportArchiveView: React.FC<ExportArchiveViewProps> = ({ state }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressText, setProgressText] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const folderName = state.cartellaOutput || 'Sentenze_GA';
  const hasDocuments = state.pronunceAcquisite > 0 || state.pronunce.length > 0;

  const handleDownloadZip = async () => {
    if (!hasDocuments || isGenerating) return;

    setIsGenerating(true);
    setErrorMessage(null);
    setSuccessMessage(null);
    setProgressText('Generazione PDF e compressione ZIP in corso...');

    try {
      await downloadSentenzeZipClient(state, (msg) => {
        setProgressText(msg);
      });

      setSuccessMessage('Archivio ZIP generato e scaricato con successo con tutti i file PDF e testi!');
      setTimeout(() => setSuccessMessage(null), 5000);
    } catch (err: any) {
      console.error('Errore durante la generazione dello ZIP:', err);
      const errMsg = err?.message || 'Si è verificato un errore imprevisto durante la generazione dello ZIP.';
      setErrorMessage(`Errore generazione archivio: ${errMsg}`);
    } finally {
      setIsGenerating(false);
      setProgressText('');
    }
  };

  const handleDownloadCsv = () => {
    window.location.href = '/api/export/csv';
  };

  return (
    <div className="space-y-6">
      {/* Feedback Toast / Alert Banner for Errors */}
      {errorMessage && (
        <div className="bg-red-950/80 border border-red-700/80 rounded-xl p-4 flex items-start gap-3 shadow-lg">
          <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-bold text-red-200">Attenzione: operazione non riuscita</h4>
            <p className="text-xs text-red-300 mt-0.5">{errorMessage}</p>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-xs text-red-400 hover:text-red-200 cursor-pointer font-semibold"
          >
            Chiudi
          </button>
        </div>
      )}

      {/* Feedback Toast for Success */}
      {successMessage && (
        <div className="bg-emerald-950/80 border border-emerald-700/80 rounded-xl p-4 flex items-start gap-3 shadow-lg">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-bold text-emerald-200">Operazione Completata</h4>
            <p className="text-xs text-emerald-300 mt-0.5">{successMessage}</p>
          </div>
          <button
            onClick={() => setSuccessMessage(null)}
            className="text-xs text-emerald-400 hover:text-emerald-200 cursor-pointer font-semibold"
          >
            Chiudi
          </button>
        </div>
      )}

      {/* Hero Export Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <FolderArchive className="w-5 h-5 text-blue-400" />
              <span>
                Archivio Documentale Ufficiale:{' '}
                <span className="font-mono text-blue-400">{folderName}</span>
              </span>
            </h2>
            <p className="text-xs text-slate-400 max-w-2xl">
              Costruzione lato client del pacchetto ZIP conforme con inclusione di tutti i singoli file PDF
              delle sentenze (con intestazione, numero provvedimento, data e testo integrale), copie originali,
              testi TXT per AI, indice CSV e report di audit.
            </p>
          </div>

          <div className="flex flex-col items-end gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={!hasDocuments || isGenerating}
              className={`flex items-center gap-2.5 px-6 py-3.5 text-sm font-bold text-white rounded-xl shadow-lg transition-all ${
                isGenerating
                  ? 'bg-blue-800 cursor-wait opacity-90'
                  : hasDocuments
                  ? 'bg-blue-600 hover:bg-blue-500 hover:shadow-blue-900/40 cursor-pointer'
                  : 'bg-slate-800 opacity-60 cursor-not-allowed'
              }`}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-blue-200" />
                  <span>Generazione PDF e compressione ZIP in corso...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>
                    Scarica Archivio Completo ZIP ({state.pronunceAcquisite} pronunce)
                  </span>
                </>
              )}
            </button>

            {isGenerating && progressText && (
              <span className="text-xs text-blue-400 font-mono animate-pulse">
                {progressText}
              </span>
            )}
          </div>
        </div>

        {/* Directory Structure Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {/* Card 1: Documenti PDF Formattati */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-2 text-rose-400 mb-2">
              <FileCheck className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">1. Singoli File PDF</h3>
            </div>
            <p className="text-xs font-mono text-slate-400 mb-2">sentenza_[numero].pdf</p>
            <p className="text-xs text-slate-400 leading-relaxed">
              Ogni pronuncia viene compilata in formato PDF A4 completo di intestazione Repubblica Italiana,
              estremi giudiziari, P.Q.M. e motivazione.
            </p>
          </div>

          {/* Card 2: Testi Integrali TXT */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-2 text-emerald-400 mb-2">
              <FileText className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">2. Testi Integrali TXT</h3>
            </div>
            <p className="text-xs font-mono text-slate-400 mb-2">testi_integrali/*.txt</p>
            <p className="text-xs text-slate-400 leading-relaxed">
              File TXT codificati UTF-8 privi di markup grafico, ideali per elaborazioni con intelligenza
              artificiale, sistemi RAG e banche dati legali.
            </p>
          </div>

          {/* Card 3: Documenti Originali HTML */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-2 text-blue-400 mb-2">
              <FileCode className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">3. Documenti Originali</h3>
            </div>
            <p className="text-xs font-mono text-slate-400 mb-2">documenti_originali/*.html</p>
            <p className="text-xs text-slate-400 leading-relaxed">
              Copia identica e conforme del file XML/HTML pubblicato sul repository documentale ufficiale{' '}
              <code>mdp.giustizia-amministrativa.it</code>.
            </p>
          </div>

          {/* Card 4: Indice CSV & Report */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-2 text-amber-400 mb-2">
              <FileSpreadsheet className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">4. Indice CSV & Audit</h3>
            </div>
            <p className="text-xs font-mono text-slate-400 mb-2">indice_pronunce.csv</p>
            <p className="text-xs text-slate-400 leading-relaxed">
              Tabella metadati con numerazione, date, RG, ECLI e link originali, affiancata dal report
              di audit in JSON e Markdown.
            </p>
            <div className="mt-3 flex items-center gap-2 text-xs">
              <button
                onClick={handleDownloadCsv}
                className="text-xs text-blue-400 hover:text-blue-300 font-semibold underline inline-flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3 h-3" />
                <span>Scarica CSV</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Standalone Windows Executable Package Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-950/60 rounded-xl border border-blue-800/50 text-blue-400">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Pacchetto Standalone per Windows (Esecuzione Offline)</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Script batch pronto all'uso con doppio clic (<code>run_estrazione.bat</code>) e motore Python autonomo per estrazioni programmate su macchine Windows.
              </p>
            </div>
          </div>

          <div>
            <a
              href="/api/export/windows-package"
              download
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Scarica Pacchetto Windows (.bat + Python)</span>
            </a>
          </div>
        </div>

        <div className="mt-4 bg-slate-950 p-4 rounded-lg font-mono text-xs text-slate-300 space-y-2 border border-slate-800/80">
          <div className="text-slate-400 font-semibold">Istruzioni rapide d'uso su Windows:</div>
          <ol className="list-decimal list-inside space-y-1 text-slate-400">
            <li>Estrai l'archivio ZIP scaricato sul computer Windows.</li>
            <li>Fai doppio clic sul file <strong className="text-white">run_estrazione.bat</strong>.</li>
            <li>Il programma installerà automaticamente le dipendenze leggere (requests) ed eseguirà l'estrazione.</li>
            <li>Tutti i file saranno salvati nella sottocartella <strong className="text-blue-400">Sentenze_GA_AAAA-MM-GG</strong> creata automaticamente.</li>
          </ol>
        </div>
      </div>
    </div>
  );
};
