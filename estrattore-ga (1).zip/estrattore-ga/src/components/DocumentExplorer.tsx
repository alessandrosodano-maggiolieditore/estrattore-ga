/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Search, Filter, Eye, Download, FileText, CheckCircle2, XCircle, AlertCircle, ExternalLink } from 'lucide-react';
import { GAPronuncia } from '../types/scraper.js';

interface DocumentExplorerProps {
  documents: GAPronuncia[];
  onSelectDocument: (doc: GAPronuncia) => void;
}

export const DocumentExplorer: React.FC<DocumentExplorerProps> = ({ documents, onSelectDocument }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTipo, setSelectedTipo] = useState('');
  const [selectedSede, setSelectedSede] = useState('');
  const [selectedStato, setSelectedStato] = useState('');
  // ID delle pronunce il cui testo integrale contiene il termine cercato (ricerca lato server)
  const [textMatches, setTextMatches] = useState<Set<string>>(new Set());

  useEffect(() => {
    const q = searchTerm.trim();
    if (q.length < 3) {
      setTextMatches(new Set());
      return;
    }
    const controller = new AbortController();
    const timer = setTimeout(() => {
      fetch(`/api/documents/search?q=${encodeURIComponent(q)}`, { signal: controller.signal })
        .then((res) => (res.ok ? res.json() : { ids: [] }))
        .then((data) => setTextMatches(new Set(data.ids)))
        .catch(() => {});
    }, 300);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [searchTerm, documents.length]);

  const sediList = Array.from(new Set(documents.map((d) => d.sede).filter(Boolean))).sort();
  const tipiList = Array.from(new Set(documents.map((d) => d.tipologia).filter(Boolean))).sort();

  const filteredDocs = documents.filter((doc) => {
    if (selectedTipo && doc.tipologia !== selectedTipo) return false;
    if (selectedSede && doc.sede !== selectedSede) return false;
    if (selectedStato && doc.statusAcquisizione !== selectedStato) return false;

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const match =
        doc.numeroProvvedimento.toLowerCase().includes(q) ||
        doc.numeroRicorso.toLowerCase().includes(q) ||
        doc.sede.toLowerCase().includes(q) ||
        doc.sezione.toLowerCase().includes(q) ||
        doc.ecli.toLowerCase().includes(q) ||
        doc.tipologia.toLowerCase().includes(q) ||
        textMatches.has(doc.id);
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
      {/* Header & Filter Controls */}
      <div className="p-5 border-b border-slate-800 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Elenco Pronunce Acquisite</span>
              <span className="text-xs font-mono font-medium text-blue-400 bg-slate-800 px-2 py-0.5 rounded">
                {filteredDocs.length} di {documents.length}
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Esplora i provvedimenti estratti con accesso immediato a testo integrale (TXT), documento originale (PDF/HTML).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="/api/export/csv"
              download
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Esporta Indice CSV</span>
            </a>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-1">
          {/* Search box */}
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cerca per n. provv, RG, ECLI, testo..."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5 pointer-events-none" />
          </div>

          {/* Sede */}
          <div>
            <select
              value={selectedSede}
              onChange={(e) => setSelectedSede(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="">Tutte le Sedi ({sediList.length})</option>
              {sediList.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* Tipologia */}
          <div>
            <select
              value={selectedTipo}
              onChange={(e) => setSelectedTipo(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="">Tutte le Tipologie ({tipiList.length})</option>
              {tipiList.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* Stato */}
          <div>
            <select
              value={selectedStato}
              onChange={(e) => setSelectedStato(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="">Tutti gli Stati</option>
              <option value="completata">Acquisita con successo (OK)</option>
              <option value="fallita">Fallita / Errore</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        {documents.length === 0 ? (
          <div className="text-center py-20 text-slate-500 text-xs">
            Nessun provvedimento in archivio. Esegui la ricerca per popolare l'elenco.
          </div>
        ) : filteredDocs.length === 0 ? (
          <div className="text-center py-16 text-slate-500 text-xs">
            Nessuna pronuncia corrisponde ai filtri di ricerca applicati.
          </div>
        ) : (
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                <th className="py-2.5 px-4">Autorità / Sede</th>
                <th className="py-2.5 px-3">Sezione</th>
                <th className="py-2.5 px-3">Tipologia</th>
                <th className="py-2.5 px-3">N. Provvedimento</th>
                <th className="py-2.5 px-3">N. Ricorso (RG)</th>
                <th className="py-2.5 px-3">Data Pubbl.</th>
                <th className="py-2.5 px-3">ECLI</th>
                <th className="py-2.5 px-3">Stato</th>
                <th className="py-2.5 px-4 text-right">Azioni</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {filteredDocs.map((doc) => {
                const isOk = doc.statusAcquisizione === 'completata';
                return (
                  <tr
                    key={doc.id}
                    onClick={() => onSelectDocument(doc)}
                    className="hover:bg-slate-800/50 cursor-pointer transition-colors"
                  >
                    <td className="py-2.5 px-4 font-sans font-medium text-white whitespace-nowrap">
                      {doc.autorita} ({doc.sede})
                    </td>
                    <td className="py-2.5 px-3 text-slate-300 whitespace-nowrap">
                      {doc.sezione || '-'}
                    </td>
                    <td className="py-2.5 px-3 font-sans font-semibold text-slate-200 whitespace-nowrap">
                      {doc.tipologia}
                    </td>
                    <td className="py-2.5 px-3 text-blue-400 font-semibold tabular-nums whitespace-nowrap">
                      {doc.numeroProvvedimento}/{doc.annoProvvedimento}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 tabular-nums whitespace-nowrap">
                      {doc.numeroRicorso}/{doc.annoRicorso}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300 tabular-nums whitespace-nowrap">
                      {doc.dataPubblicazione}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 max-w-[150px] truncate" title={doc.ecli}>
                      {doc.ecli || '-'}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      {isOk ? (
                        <span className="text-emerald-400 font-medium flex items-center gap-1 font-sans">
                          <CheckCircle2 className="w-3.5 h-3.5 inline text-emerald-400" />
                          <span>OK</span>
                        </span>
                      ) : (
                        <span className="text-red-400 font-medium flex items-center gap-1 font-sans" title={doc.errore || ''}>
                          <XCircle className="w-3.5 h-3.5 inline text-red-400" />
                          <span>Fallito</span>
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onSelectDocument(doc)}
                          title="Visualizza pronuncia (TXT, HTML, PDF)"
                          className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {doc.urlOriginale && (
                          <a
                            href={doc.urlOriginale}
                            target="_blank"
                            rel="noreferrer"
                            title="Apri documento su portale GA"
                            className="p-1 text-slate-400 hover:text-blue-400 hover:bg-slate-700 rounded transition-colors"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
