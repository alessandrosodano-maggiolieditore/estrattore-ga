/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileText,
  Clock,
  Layers,
  Search,
  Activity,
  Copy,
} from 'lucide-react';
import { ExtractionState, LogEntry } from '../types/scraper.js';

interface ProgressDashboardProps {
  state: ExtractionState;
}

export const ProgressDashboard: React.FC<ProgressDashboardProps> = ({ state }) => {
  const [logFilter, setLogFilter] = useState<'all' | 'error' | 'warn' | 'success'>('all');
  const [searchLog, setSearchLog] = useState('');
  const [copiedLog, setCopiedLog] = useState(false);

  const filteredLogs = state.logs.filter((l) => {
    if (logFilter !== 'all' && l.level !== logFilter) return false;
    if (searchLog.trim()) {
      return l.message.toLowerCase().includes(searchLog.toLowerCase());
    }
    return true;
  });

  const copyAllLogs = () => {
    const text = state.logs.map((l) => `[${l.timestamp}] [${l.level.toUpperCase()}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopiedLog(true);
    setTimeout(() => setCopiedLog(false), 2000);
  };

  const getStatusBadge = () => {
    switch (state.status) {
      case 'running':
        return (
          <span className="text-xs font-semibold text-blue-400 flex items-center gap-1.5 font-mono">
            <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse inline-block"></span>
            IN ESECUZIONE
          </span>
        );
      case 'paused':
        return (
          <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5 font-mono">
            <span className="w-2 h-2 rounded-full bg-amber-500 inline-block"></span>
            IN PAUSA
          </span>
        );
      case 'completed':
        return (
          <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5 font-mono">
            <CheckCircle2 className="w-3.5 h-3.5 inline" />
            COMPLETATA
          </span>
        );
      case 'stopped':
        return (
          <span className="text-xs font-semibold text-red-400 flex items-center gap-1.5 font-mono">
            <XCircle className="w-3.5 h-3.5 inline" />
            INTERROTTA
          </span>
        );
      case 'failed':
        return (
          <span className="text-xs font-semibold text-red-400 flex items-center gap-1.5 font-mono">
            <AlertTriangle className="w-3.5 h-3.5 inline" />
            ERRORE
          </span>
        );
      default:
        return (
          <span className="text-xs text-slate-400 font-mono">IN ATTESA</span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Metric 1: Dichiarati dal Portale */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs font-medium text-slate-400 mb-1 flex items-center justify-between">
            <span>Dichiarati dal Portale</span>
            <Layers className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {state.risultatiDichiaratiPortale}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Totale dichiarato</p>
        </div>

        {/* Metric 2: Individuati */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs font-medium text-slate-400 mb-1 flex items-center justify-between">
            <span>Individuati</span>
            <Search className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <div className="text-2xl font-bold text-slate-200 font-mono tabular-nums">
            {state.risultatiIndividuati}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Provvedimenti parsati</p>
        </div>

        {/* Metric 3: Scaricati con successo */}
        <div className="bg-slate-900 border border-emerald-950/60 rounded-xl p-4">
          <div className="text-xs font-medium text-emerald-400 mb-1 flex items-center justify-between">
            <span>Acquisiti (OK)</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            {state.pronunceAcquisite}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Testo integrale & originali</p>
        </div>

        {/* Metric 4: Errori / Falliti */}
        <div className="bg-slate-900 border border-red-950/60 rounded-xl p-4">
          <div className="text-xs font-medium text-red-400 mb-1 flex items-center justify-between">
            <span>Falliti</span>
            <XCircle className="w-3.5 h-3.5 text-red-400" />
          </div>
          <div className="text-2xl font-bold text-red-400 font-mono tabular-nums">
            {state.acquisizioniFallite}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Con link per retry</p>
        </div>

        {/* Metric 5: Duplicati scartati */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs font-medium text-slate-400 mb-1 flex items-center justify-between">
            <span>Duplicati Scartati</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-amber-400 font-mono tabular-nums">
            {state.duplicatiScartati}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Deduplicazione attiva</p>
        </div>

        {/* Metric 6: Paginazione */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs font-medium text-slate-400 mb-1 flex items-center justify-between">
            <span>Pagine Elaborate</span>
            <Clock className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <div className="text-xl font-bold text-blue-400 font-mono tabular-nums">
            {state.paginaCorrente} / {state.totalePagine || '-'}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {state.velocitaDocSec > 0 ? `${state.velocitaDocSec} doc/s` : 'Max 60 per pag.'}
          </p>
        </div>
      </div>

      {/* Progress Bar & Status Line */}
      {(state.status === 'running' || state.status === 'paused' || state.pronunceAcquisite > 0) && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-3">
              <span className="text-sm font-bold text-white">Stato Operazione:</span>
              {getStatusBadge()}
            </div>
            <div className="text-sm font-mono font-bold text-blue-400 tabular-nums">
              {state.percentuale}%
            </div>
          </div>

          {/* Track */}
          <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
            <div
              className={`h-full transition-all duration-300 rounded-full ${
                state.status === 'completed'
                  ? 'bg-emerald-500'
                  : state.status === 'paused'
                  ? 'bg-amber-500'
                  : state.status === 'stopped'
                  ? 'bg-red-500'
                  : 'bg-blue-600'
              }`}
              style={{ width: `${Math.max(2, state.percentuale)}%` }}
            ></div>
          </div>

          <div className="flex flex-wrap items-center justify-between text-xs text-slate-400 mt-2.5 pt-1">
            <div className="flex items-center gap-2">
              <span>
                Documenti trattati:{' '}
                <strong className="text-white font-mono">
                  {state.pronunceAcquisite + state.acquisizioniFallite} / {state.risultatiDichiaratiPortale}
                </strong>
              </span>
              <span>·</span>
              <span>
                Cartella:{' '}
                <strong className="text-blue-400 font-mono">{state.cartellaOutput}</strong>
              </span>
            </div>

            {state.velocitaDocSec > 0 && state.status === 'running' && (
              <div className="text-slate-400 font-mono">
                Velocità: <span className="text-emerald-400 font-semibold">{state.velocitaDocSec} doc/sec</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Live Event Log Console */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-bold text-white">Registro Operativo in Tempo Reale</h3>
            <span className="text-xs text-slate-500 font-mono">({filteredLogs.length} eventi)</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter buttons */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => setLogFilter('all')}
                className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                  logFilter === 'all' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Tutti
              </button>
              <button
                onClick={() => setLogFilter('error')}
                className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                  logFilter === 'error' ? 'bg-red-950 text-red-300 font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Errori
              </button>
              <button
                onClick={() => setLogFilter('warn')}
                className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                  logFilter === 'warn' ? 'bg-amber-950 text-amber-300 font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Avvisi
              </button>
              <button
                onClick={() => setLogFilter('success')}
                className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                  logFilter === 'success' ? 'bg-emerald-950 text-emerald-300 font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Successi
              </button>
            </div>

            <button
              onClick={copyAllLogs}
              title="Copia log negli appunti"
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedLog ? 'Copiato!' : 'Copia'}</span>
            </button>
          </div>
        </div>

        {/* Log Viewer Container */}
        <div className="bg-slate-950 rounded-lg border border-slate-800 p-3 h-52 overflow-y-auto font-mono text-xs space-y-1.5">
          {filteredLogs.length === 0 ? (
            <div className="text-slate-600 text-center py-16">
              Nessun evento registrato. Configura i parametri e premi "Avvia estrazione".
            </div>
          ) : (
            filteredLogs.map((log) => {
              let color = 'text-slate-300';
              let badge = 'INFO';
              if (log.level === 'error') {
                color = 'text-red-400';
                badge = 'ERR';
              } else if (log.level === 'warn') {
                color = 'text-amber-400';
                badge = 'WARN';
              } else if (log.level === 'success') {
                color = 'text-emerald-400';
                badge = 'OK';
              }

              return (
                <div key={log.id} className="flex items-start gap-2 leading-relaxed hover:bg-slate-900/60 px-1.5 py-0.5 rounded">
                  <span className="text-slate-500 shrink-0 tabular-nums">{log.timestamp}</span>
                  <span className={`text-[10px] font-bold px-1 rounded shrink-0 ${
                    log.level === 'error' ? 'bg-red-950 text-red-400' :
                    log.level === 'warn' ? 'bg-amber-950 text-amber-400' :
                    log.level === 'success' ? 'bg-emerald-950 text-emerald-400' :
                    'bg-slate-800 text-slate-400'
                  }`}>
                    {badge}
                  </span>
                  <span className={`${color} break-all`}>{log.message}</span>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
