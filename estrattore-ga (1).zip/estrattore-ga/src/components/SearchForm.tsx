/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Play, Pause, Square, RotateCcw, Calendar, Search, Filter, FolderDown, AlertCircle } from 'lucide-react';
import { ExtractionParams, ExtractionState } from '../types/scraper.js';

interface SearchFormProps {
  state: ExtractionState;
  onStart: (params: ExtractionParams) => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
  onViewDocuments: () => void;
}

export const SearchForm: React.FC<SearchFormProps> = ({
  state,
  onStart,
  onPause,
  onResume,
  onStop,
  onViewDocuments,
}) => {
  const [paroleChiave, setParoleChiave] = useState(state.params.paroleChiave || 'gara');
  const [fraseEsatta, setFraseEsatta] = useState(state.params.fraseEsatta || '');
  const [sede, setSede] = useState(state.params.sede || '');
  const [tipoProvvedimento, setTipoProvvedimento] = useState(state.params.tipoProvvedimento || '');
  const [modalitaRicerca, setModalitaRicerca] = useState<'provv' | 'nrg'>(state.params.modalitaRicerca || 'provv');
  const [risultatiPerPagina, setRisultatiPerPagina] = useState(state.params.risultatiPerPagina || 60);

  const isRunning = state.status === 'running';
  const isPaused = state.status === 'paused';

  const setTodayDate = () => {
    const formatter = new Intl.DateTimeFormat('it-IT', {
      timeZone: 'Europe/Rome',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
    setFraseEsatta(formatter.format(new Date()));
  };

  const setYesterdayDate = () => {
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const formatter = new Intl.DateTimeFormat('it-IT', {
      timeZone: 'Europe/Rome',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
    setFraseEsatta(formatter.format(yesterday));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStart({
      paroleChiave,
      fraseEsatta,
      sede,
      tipoProvvedimento,
      modalitaRicerca,
      risultatiPerPagina,
    });
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
      <div className="flex items-center justify-between pb-4 mb-5 border-b border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <span>Maschera di Ricerca "Decisioni e Pareri"</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Interrogazione conforme al portale ufficiale GA (<code>/web/guest/dcsnprr</code>) con fuso orario{' '}
            <strong className="text-slate-300">Europe/Rome</strong>.
          </p>
        </div>
        <div className="text-right hidden sm:block">
          <span className="text-xs text-slate-400">Cartella di salvataggio:</span>
          <p className="text-xs font-mono font-medium text-blue-400">{state.cartellaOutput}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Campo 1: Che contenga tutte le seguenti parole */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wide mb-1.5">
              Che contenga tutte le seguenti parole
            </label>
            <div className="relative">
              <input
                type="text"
                value={paroleChiave}
                onChange={(e) => setParoleChiave(e.target.value)}
                disabled={isRunning}
                placeholder="es. gara"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-60"
              />
              <span className="absolute right-3 top-2.5 text-xs text-slate-500 font-mono">default: gara</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Parametro principale di ricerca per appalti e procedure ad evidenza pubblica.
            </p>
          </div>

          {/* Campo 2: Che contenga la seguente frase (Data) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wide">
                Che contenga la seguente frase (Data GG/MM/AAAA)
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={setTodayDate}
                  disabled={isRunning}
                  className="text-[11px] text-blue-400 hover:text-blue-300 underline font-medium cursor-pointer"
                >
                  Oggi
                </button>
                <span className="text-slate-600">·</span>
                <button
                  type="button"
                  onClick={setYesterdayDate}
                  disabled={isRunning}
                  className="text-[11px] text-slate-400 hover:text-slate-300 underline cursor-pointer"
                >
                  Ieri
                </button>
              </div>
            </div>
            <div className="relative">
              <input
                type="text"
                value={fraseEsatta}
                onChange={(e) => setFraseEsatta(e.target.value)}
                disabled={isRunning}
                placeholder="es. 20/10/2026"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-mono disabled:opacity-60"
              />
              <Calendar className="w-4 h-4 text-slate-500 absolute right-3 top-3 pointer-events-none" />
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Data calcolata su fuso orario italiano. Lasciare vuoto per cercare senza filtro di data.
            </p>
          </div>
        </div>

        {/* Modalità di ricerca & Risultati per pagina */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wide mb-1.5">
              Modalità di ricerca
            </label>
            <div className="flex items-center gap-4 bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2">
              <label className="flex items-center gap-2 text-sm text-slate-200 cursor-pointer">
                <input
                  type="radio"
                  name="modalita"
                  value="provv"
                  checked={modalitaRicerca === 'provv'}
                  onChange={() => setModalitaRicerca('provv')}
                  disabled={isRunning}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span>Provvedimento</span>
              </label>
              <label className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer">
                <input
                  type="radio"
                  name="modalita"
                  value="nrg"
                  checked={modalitaRicerca === 'nrg'}
                  onChange={() => setModalitaRicerca('nrg')}
                  disabled={isRunning}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span>N. Ricorso (RG)</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wide mb-1.5">
              Risultati per pagina
            </label>
            <select
              value={risultatiPerPagina}
              onChange={(e) => setRisultatiPerPagina(Number(e.target.value))}
              disabled={isRunning}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono disabled:opacity-60"
            >
              <option value={60}>60 (Massimo consentito dalla piattaforma)</option>
              <option value={40}>40</option>
              <option value={20}>20</option>
            </select>
          </div>

          {/* Sede giurisdizionale */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wide mb-1.5">
              Filtro Sede (Opzionale)
            </label>
            <select
              value={sede}
              onChange={(e) => setSede(e.target.value)}
              disabled={isRunning}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 disabled:opacity-60"
            >
              <option value="">Tutte le sedi (Consiglio di Stato, CGA, TAR)</option>
              <option value="Roma">TAR Lazio - Roma</option>
              <option value="Milano">TAR Lombardia - Milano</option>
              <option value="Napoli">TAR Campania - Napoli</option>
              <option value="Bari">TAR Puglia - Bari</option>
              <option value="Bologna">TAR Emilia Romagna - Bologna</option>
              <option value="Catania">TAR Sicilia - Catania</option>
              <option value="Firenze">TAR Toscana - Firenze</option>
              <option value="Palermo">TAR Sicilia - Palermo</option>
              <option value="Torino">TAR Piemonte - Torino</option>
              <option value="Venezia">TAR Veneto - Venezia</option>
            </select>
          </div>
        </div>

        {/* Action Buttons Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
          <div className="flex flex-wrap items-center gap-3">
            {!isRunning && !isPaused && (
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors shadow-lg shadow-blue-900/30 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Avvia estrazione</span>
              </button>
            )}

            {isRunning && (
              <button
                type="button"
                onClick={onPause}
                className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-amber-600 rounded-lg hover:bg-amber-500 transition-colors shadow-lg cursor-pointer"
              >
                <Pause className="w-4 h-4" />
                <span>Metti in pausa</span>
              </button>
            )}

            {isPaused && (
              <button
                type="button"
                onClick={onResume}
                className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-500 transition-colors shadow-lg cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Riprendi estrazione</span>
              </button>
            )}

            {(isRunning || isPaused) && (
              <button
                type="button"
                onClick={onStop}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-red-300 hover:text-white bg-red-950/60 border border-red-800/80 rounded-lg hover:bg-red-900 transition-colors cursor-pointer"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>Interrompi operazione</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            {state.pronunceAcquisite > 0 && (
              <button
                type="button"
                onClick={onViewDocuments}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg border border-slate-700 hover:border-slate-600 transition-colors cursor-pointer"
              >
                <FolderDown className="w-3.5 h-3.5" />
                <span>Visualizza {state.pronunceAcquisite} pronunce acquisite</span>
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};
