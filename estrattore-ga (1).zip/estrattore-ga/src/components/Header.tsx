/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Download, ExternalLink, Loader2 } from 'lucide-react';
import { ExtractionState } from '../types/scraper.js';
import { downloadSentenzeZipClient } from '../utils/zipClientExporter.js';

interface HeaderProps {
  currentTab: 'search' | 'documents' | 'export' | 'scheduler' | 'diagnostics';
  onSelectTab: (tab: 'search' | 'documents' | 'export' | 'scheduler' | 'diagnostics') => void;
  state: ExtractionState;
}

export const Header: React.FC<HeaderProps> = ({ currentTab, onSelectTab, state }) => {
  const isRunning = state.status === 'running';
  const [isExporting, setIsExporting] = useState(false);

  const handleDownloadZip = async () => {
    if (isExporting || state.pronunceAcquisite === 0) return;
    setIsExporting(true);
    try {
      await downloadSentenzeZipClient(state);
    } catch (err: any) {
      console.error('Errore download ZIP:', err);
      alert(`Errore durante la generazione dello ZIP: ${err?.message || err}`);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            onSelectTab('search');
          }}
          className="text-base font-bold tracking-tight text-white whitespace-nowrap hover:text-blue-400 transition-colors flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 rounded-sm bg-blue-500 inline-block"></span>
          <span>Giustizia Amministrativa</span>
          <span className="text-slate-400 text-xs font-normal">| Estrattore dcsnprr</span>
        </a>
      </div>

      {/* Zone 2: 4-5 clean single-line navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
        <button
          onClick={() => onSelectTab('search')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-1 cursor-pointer ${
            currentTab === 'search' ? 'text-white border-b-2 border-blue-500 font-semibold' : ''
          }`}
        >
          Estrazione {isRunning && <span className="text-blue-400 text-xs ml-1 font-mono">(In corso)</span>}
        </button>

        <button
          onClick={() => onSelectTab('documents')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-1 cursor-pointer flex items-center gap-1.5 ${
            currentTab === 'documents' ? 'text-white border-b-2 border-blue-500 font-semibold' : ''
          }`}
        >
          <span>Pronunce Acquisite</span>
          {state.pronunceAcquisite > 0 && (
            <span className="text-xs bg-slate-800 text-blue-400 px-1.5 py-0.2 rounded font-mono">
              {state.pronunceAcquisite}
            </span>
          )}
        </button>

        <button
          onClick={() => onSelectTab('export')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-1 cursor-pointer ${
            currentTab === 'export' ? 'text-white border-b-2 border-blue-500 font-semibold' : ''
          }`}
        >
          Archivio ZIP & Report
        </button>

        <button
          onClick={() => onSelectTab('scheduler')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-1 cursor-pointer ${
            currentTab === 'scheduler' ? 'text-white border-b-2 border-blue-500 font-semibold' : ''
          }`}
        >
          Pianificatore
        </button>

        <button
          onClick={() => onSelectTab('diagnostics')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-1 cursor-pointer ${
            currentTab === 'diagnostics' ? 'text-white border-b-2 border-blue-500 font-semibold' : ''
          }`}
        >
          Diagnostica Portale
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        {state.pronunceAcquisite > 0 ? (
          <button
            onClick={handleDownloadZip}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0 shadow-sm cursor-pointer disabled:opacity-75 disabled:cursor-wait"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Generazione ZIP...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Scarica Archivio ZIP ({state.pronunceAcquisite})</span>
              </>
            )}
          </button>
        ) : (
          <a
            href="https://www.giustizia-amministrativa.it/de/dcsnprr"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <span>Portale Ufficiale</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </a>
        )}
      </div>
    </header>
  );
};
