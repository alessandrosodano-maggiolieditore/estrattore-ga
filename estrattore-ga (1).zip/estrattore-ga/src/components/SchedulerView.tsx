/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Clock, Calendar, Check, Save, AlertCircle, Play, ToggleLeft, ToggleRight } from 'lucide-react';
import { ScheduleConfig } from '../types/scraper.js';

export const SchedulerView: React.FC = () => {
  const [config, setConfig] = useState<ScheduleConfig>({
    attivo: false,
    ora: '08:00',
    paroleChiave: 'gara',
    usaDataCorrente: true,
    ultimaEsecuzione: null,
    prossimaEsecuzione: null,
    statoUltimaEsecuzione: null,
  });
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/scheduler')
      .then((res) => res.json())
      .then((data) => {
        setConfig(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching schedule config:', err);
        setLoading(false);
      });
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/scheduler', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      const data = await res.json();
      setConfig(data);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (err) {
      console.error('Error updating scheduler:', err);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-500 text-xs">Caricamento impostazioni pianificatore...</div>;
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl max-w-3xl mx-auto space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Clock className="w-5 h-5 text-blue-400" />
          <span>Pianificatore Estrazione Giornaliera Automatica</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Configura l'interrogazione periodica del portale Giustizia Amministrativa ogni mattina per acquisire tutte le pronunce pubblicate nel giorno.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-5">
        {/* Toggle Attivo */}
        <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
          <div>
            <div className="text-sm font-bold text-white">Abilita Esecuzione Quotidiana</div>
            <div className="text-xs text-slate-400">
              L'applicazione avvierà l'estrazione ogni giorno all'orario indicato (fuso orario Europe/Rome).
            </div>
          </div>
          <button
            type="button"
            onClick={() => setConfig({ ...config, attivo: !config.attivo })}
            className="cursor-pointer"
          >
            {config.attivo ? (
              <ToggleRight className="w-10 h-10 text-emerald-400" />
            ) : (
              <ToggleLeft className="w-10 h-10 text-slate-600" />
            )}
          </button>
        </div>

        {/* Orario & Parole Chiave */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wide mb-1.5">
              Ora di esecuzione (Europe/Rome)
            </label>
            <input
              type="time"
              value={config.ora}
              onChange={(e) => setConfig({ ...config, ora: e.target.value })}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
            />
            <p className="text-[11px] text-slate-500 mt-1">Formato 24 ore (es. 08:30)</p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wide mb-1.5">
              Parole Chiave
            </label>
            <input
              type="text"
              value={config.paroleChiave}
              onChange={(e) => setConfig({ ...config, paroleChiave: e.target.value })}
              placeholder="es. gara"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
            />
            <p className="text-[11px] text-slate-500 mt-1">Termine di ricerca predefinito</p>
          </div>
        </div>

        {/* Checkbox auto date */}
        <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center gap-3">
          <input
            type="checkbox"
            id="usaDataCorrente"
            checked={config.usaDataCorrente}
            onChange={(e) => setConfig({ ...config, usaDataCorrente: e.target.checked })}
            className="w-4 h-4 text-blue-600 rounded bg-slate-900 border-slate-700 focus:ring-blue-500"
          />
          <label htmlFor="usaDataCorrente" className="text-xs text-slate-300 cursor-pointer">
            Imposta automaticamente la data del giorno corrente (GG/MM/AAAA) al momento dell'esecuzione.
          </label>
        </div>

        {/* Status display */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs font-mono">
          <div className="flex items-center justify-between text-slate-400">
            <span>Stato Pianificatore:</span>
            <span className={config.attivo ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
              {config.attivo ? 'ATTIVO (IN ASCOLTO)' : 'DISATTIVATO'}
            </span>
          </div>

          <div className="flex items-center justify-between text-slate-400">
            <span>Prossima esecuzione prevista:</span>
            <span className="text-white">
              {config.prossimaEsecuzione
                ? new Date(config.prossimaEsecuzione).toLocaleString('it-IT', { timeZone: 'Europe/Rome' })
                : '-'}
            </span>
          </div>

          <div className="flex items-center justify-between text-slate-400">
            <span>Ultima esecuzione registrata:</span>
            <span className="text-slate-300">{config.ultimaEsecuzione || 'Nessuna esecuzione recente'}</span>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="submit"
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors cursor-pointer shadow-md"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saved ? 'Impostazioni Salvate!' : 'Salva Configurazione'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
